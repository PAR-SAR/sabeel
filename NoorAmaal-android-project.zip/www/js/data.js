/* ============================================================
   NOOR AMAAL — CONTENT FILE
   Saara deeni content (ayat, hadith, azkaar, duayein) isi file
   mein hai. Publish se pehle kisi alim se ek baar verify karwa lein.
   Kuch badalna ho to sirf yahi file edit karein.
   ============================================================ */

const APP_NAME = "Noor Amaal";

/* ---------- Roz ki Ayat (short, well-known) ---------- */
const AYAT = [
  { ar: "يَا أَيُّهَا الَّذِينَ آمَنُوا كُتِبَ عَلَيْكُمُ الصِّيَامُ كَمَا كُتِبَ عَلَى الَّذِينَ مِن قَبْلِكُمْ لَعَلَّكُمْ تَتَّقُونَ", ur: "Aye imaan walo! Tum par roze farz kiye gaye jaise tumse pehle logon par farz kiye gaye the, taaki tum parhezgaar bano.", ref: "Surah Al-Baqarah 2:183" },
  { ar: "وَإِذَا سَأَلَكَ عِبَادِي عَنِّي فَإِنِّي قَرِيبٌ ۖ أُجِيبُ دَعْوَةَ الدَّاعِ إِذَا دَعَانِ", ur: "Aur jab mere bande aapse mere baare mein poochein, to main qareeb hoon. Pukaarne wale ki pukaar ka jawab deta hoon jab woh mujhe pukaarta hai.", ref: "Surah Al-Baqarah 2:186" },
  { ar: "فَاذْكُرُونِي أَذْكُرْكُمْ وَاشْكُرُوا لِي وَلَا تَكْفُرُونِ", ur: "Tum mujhe yaad karo, main tumhein yaad karunga. Aur mera shukr ada karo, na-shukri na karo.", ref: "Surah Al-Baqarah 2:152" },
  { ar: "فَإِنَّ مَعَ الْعُسْرِ يُسْرًا ۝ إِنَّ مَعَ الْعُسْرِ يُسْرًا", ur: "Beshak mushkil ke saath aasaani hai. Beshak mushkil ke saath aasaani hai.", ref: "Surah Ash-Sharh 94:5-6" },
  { ar: "أَلَا بِذِكْرِ اللَّهِ تَطْمَئِنُّ الْقُلُوبُ", ur: "Suno! Allah ke zikr se hi dilon ko sukoon milta hai.", ref: "Surah Ar-Ra'd 13:28" },
  { ar: "لَا يُكَلِّفُ اللَّهُ نَفْسًا إِلَّا وُسْعَهَا", ur: "Allah kisi jaan par uski taqat se zyada bojh nahi daalta.", ref: "Surah Al-Baqarah 2:286" },
  { ar: "لَا تَقْنَطُوا مِن رَّحْمَةِ اللَّهِ ۚ إِنَّ اللَّهَ يَغْفِرُ الذُّنُوبَ جَمِيعًا", ur: "Allah ki rehmat se na-umeed na ho. Beshak Allah saare gunah maaf kar deta hai.", ref: "Surah Az-Zumar 39:53" },
  { ar: "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ", ur: "Beshak Allah sabr karne walon ke saath hai.", ref: "Surah Al-Baqarah 2:153" },
  { ar: "إِنَّ الصَّلَاةَ تَنْهَىٰ عَنِ الْفَحْشَاءِ وَالْمُنكَرِ", ur: "Beshak namaz behayai aur buri baaton se rokti hai.", ref: "Surah Al-Ankabut 29:45" },
  { ar: "لَيْلَةُ الْقَدْرِ خَيْرٌ مِّنْ أَلْفِ شَهْرٍ", ur: "Shab-e-Qadr hazaar mahino se behtar hai.", ref: "Surah Al-Qadr 97:3" },
  { ar: "شَهْرُ رَمَضَانَ الَّذِي أُنزِلَ فِيهِ الْقُرْآنُ هُدًى لِّلنَّاسِ", ur: "Ramadan woh mahina hai jisme Quran utaara gaya, logon ke liye hidayat.", ref: "Surah Al-Baqarah 2:185" },
  { ar: "وَمَن يَتَوَكَّلْ عَلَى اللَّهِ فَهُوَ حَسْبُهُ", ur: "Aur jo Allah par bharosa kare, to Allah uske liye kaafi hai.", ref: "Surah At-Talaq 65:3" },
  { ar: "وَلَا تَهِنُوا وَلَا تَحْزَنُوا وَأَنتُمُ الْأَعْلَوْنَ إِن كُنتُم مُّؤْمِنِينَ", ur: "Himmat na haaro aur gham na karo, tum hi buland rahoge agar tum momin ho.", ref: "Surah Aal-e-Imran 3:139" },
  { ar: "يَا أَيُّهَا الَّذِينَ آمَنُوا اذْكُرُوا اللَّهَ ذِكْرًا كَثِيرًا", ur: "Aye imaan walo! Allah ko kasrat se yaad karo.", ref: "Surah Al-Ahzab 33:41" },
  { ar: "وَقُل رَّبِّ زِدْنِي عِلْمًا", ur: "Aur kaho: Aye mere Rab, mere ilm mein izafa farma.", ref: "Surah Ta-Ha 20:114" },
  { ar: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", ur: "Aye hamare Rab! Hamein duniya mein bhi bhalai de aur aakhirat mein bhi bhalai de, aur hamein aag ke azaab se bacha.", ref: "Surah Al-Baqarah 2:201" }
];

/* ---------- Roz ki Hadith ---------- */
const HADITH = [
  { text: "Amaal ka daromadar niyyaton par hai, aur har shakhs ko wahi milega jiski usne niyyat ki.", ref: "Sahih Bukhari 1" },
  { text: "Jo shakhs imaan ke saath aur sawab ki umeed mein Ramadan ke roze rakhe, uske pichle gunah maaf kar diye jaate hain.", ref: "Sahih Bukhari 38, Sahih Muslim 760" },
  { text: "Jab Ramadan aata hai to jannat ke darwaze khol diye jaate hain, jahannam ke darwaze band kar diye jaate hain aur shayateen jakad diye jaate hain.", ref: "Sahih Bukhari 1899, Sahih Muslim 1079" },
  { text: "Sehri khaya karo, kyunki sehri mein barkat hai.", ref: "Sahih Bukhari 1923, Sahih Muslim 1095" },
  { text: "Log us waqt tak bhalai par rahenge jab tak iftar mein jaldi karte rahenge.", ref: "Sahih Bukhari 1957, Sahih Muslim 1098" },
  { text: "Jo kisi rozedaar ka roza iftar karaye, use bhi utna hi sawab milega, aur rozedaar ke sawab mein koi kami nahi hogi.", ref: "Jami' Tirmidhi 807" },
  { text: "Allah ko sabse pasand amal woh hai jo hamesha kiya jaye, chahe thoda hi ho.", ref: "Sahih Bukhari 6464, Sahih Muslim 783" },
  { text: "Do kalime zuban par halke, mizaan mein bhaari aur Rehman ko mehboob hain: SubhanAllahi wa bihamdihi, SubhanAllahil Azeem.", ref: "Sahih Bukhari 6406, Sahih Muslim 2694" },
  { text: "Tum mein sabse behtar woh hai jo Quran seekhe aur sikhaye.", ref: "Sahih Bukhari 5027" },
  { text: "Apne bhai ke saamne muskurana bhi sadqa hai.", ref: "Jami' Tirmidhi 1956" },
  { text: "Paaki aadha imaan hai.", ref: "Sahih Muslim 223" },
  { text: "Jo Allah aur aakhirat ke din par imaan rakhta hai, woh achhi baat kahe ya khamosh rahe.", ref: "Sahih Bukhari 6018, Sahih Muslim 47" },
  { text: "Roza dhaal hai.", ref: "Sahih Bukhari 1894" },
  { text: "Jo jhoot bolna aur us par amal karna na chhode, to Allah ko is baat ki koi zaroorat nahi ki woh apna khana peena chhod de.", ref: "Sahih Bukhari 1903" },
  { text: "Shab-e-Qadr ko Ramadan ke aakhri ashre ki taaq raaton mein talaash karo.", ref: "Sahih Bukhari 2017" },
  { text: "Teen logon ki dua radd nahi hoti: rozedaar ki jab tak woh iftar kare, insaaf karne wale hakim ki, aur mazloom ki.", ref: "Jami' Tirmidhi 3598" },
  { text: "Jumma ke din mujh par kasrat se durood bheja karo.", ref: "Sunan Abu Dawud 1047" },
  { text: "Peer aur Jumeraat ko amaal pesh kiye jaate hain, to main chahta hoon ki mera amal roze ki haalat mein pesh ho.", ref: "Jami' Tirmidhi 747" }
];

/* ---------- Roz ki Naseehat (general reminders) ---------- */
const NASEEHAT = [
  "Aaj kisi ek insaan ko maaf kar dein. Dil halka ho jayega.",
  "Namaz ko waqt par padhna sabse badi kamyabi hai. Agli namaz ka intezar karein.",
  "Phone uthane se pehle Quran ki ek ayat padh lein.",
  "Walidain ko aaj ek call zaroor karein, chahe 2 minute ka ho.",
  "Thoda amal jo roz ho, bade amal se behtar hai jo kabhi kabhi ho.",
  "Zuban ki hifazat karein. Ghibat se bachna bhi ibadat hai.",
  "Sone se pehle din bhar ka hisaab apne aap se lein.",
  "Aaj chhupa ke ek sadqa karein, chahe 10 rupaye ka ho.",
  "Har kaam Bismillah se shuru karein, barkat aayegi.",
  "Dua mein apne bhai behno aur ummat ko bhi yaad rakhein.",
  "Ghusse mein khamosh ho jaana bahaduri hai.",
  "Shukr ki aadat daalein. Aaj 3 nematon ko gin kar Alhamdulillah kahein.",
  "Rizq-e-halal ki fikr karein, yahi dua qubool hone ki shart hai.",
  "Masjid ke saath dil jodein. Ek namaz jamaat ke saath zaroor padhein.",
  "Aaj kisi ko achhi baat sikhayein. Yeh sadqa-e-jaariya hai."
];

/* ---------- Subah / Shaam Azkaar ---------- */
const AZKAAR = {
  morning: [
    { id: "m1", title: "Sayyidul Istighfar", ar: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", ur: "Istighfar ki sabse afzal dua. Jo yaqeen ke saath subah padhe aur shaam se pehle faut ho jaye, woh jannati hai.", count: 1, ref: "Sahih Bukhari 6306" },
    { id: "m2", title: "Subah ki dua", ar: "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ", ur: "Aye Allah! Tere hi hukm se humne subah ki aur shaam ki, tere hi hukm se jeete aur marte hain, aur teri hi taraf uthna hai.", count: 1, ref: "Jami' Tirmidhi 3391" },
    { id: "m3", title: "Hifazat ki dua", ar: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", ur: "Allah ke naam se, jiske naam ke saath zameen aur aasmaan mein koi cheez nuqsaan nahi de sakti, aur woh sunne wala jaanne wala hai.", count: 3, ref: "Sunan Abu Dawud 5088, Jami' Tirmidhi 3388" },
    { id: "m4", title: "Raza ki dua", ar: "رَضِيتُ بِاللَّهِ رَبًّا، وَبِالْإِسْلَامِ دِينًا، وَبِمُحَمَّدٍ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ نَبِيًّا", ur: "Main Allah ke Rab hone, Islam ke deen hone aur Muhammad ﷺ ke Nabi hone par raazi hoon.", count: 3, ref: "Sunan Abu Dawud 5072" },
    { id: "m5", title: "Teen Qul", ar: "سورة الإخلاص، سورة الفلق، سورة الناس", ur: "Surah Ikhlas, Surah Falaq aur Surah Naas, teen teen martaba. Har cheez se kaafi hain.", count: 3, ref: "Sunan Abu Dawud 5082, Jami' Tirmidhi 3575", quran: 112 },
    { id: "m6", title: "Tasbeeh", ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", ur: "SubhanAllahi wa bihamdihi, 100 martaba. Gunah maaf ho jaate hain chahe samundar ke jhaag ke baraabar hon.", count: 100, ref: "Sahih Muslim 2692, Sahih Bukhari 6405" }
  ],
  evening: [
    { id: "e1", title: "Sayyidul Istighfar", ar: "اللَّهُمَّ أَنْتَ رَبِّي لَا إِلَهَ إِلَّا أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي، فَإِنَّهُ لَا يَغْفِرُ الذُّنُوبَ إِلَّا أَنْتَ", ur: "Jo yaqeen ke saath shaam ko padhe aur subah se pehle faut ho jaye, woh jannati hai.", count: 1, ref: "Sahih Bukhari 6306" },
    { id: "e2", title: "Shaam ki dua", ar: "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ الْمَصِيرُ", ur: "Aye Allah! Tere hi hukm se humne shaam ki aur subah ki, tere hi hukm se jeete aur marte hain, aur teri hi taraf lautna hai.", count: 1, ref: "Jami' Tirmidhi 3391" },
    { id: "e3", title: "Panah ki dua", ar: "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ", ur: "Main Allah ke kaamil kalimaat ki panah mein aata hoon har us cheez ki buraai se jo usne paida ki.", count: 3, ref: "Sahih Muslim 2709" },
    { id: "e4", title: "Hifazat ki dua", ar: "بِسْمِ اللَّهِ الَّذِي لَا يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الْأَرْضِ وَلَا فِي السَّمَاءِ وَهُوَ السَّمِيعُ الْعَلِيمُ", ur: "Allah ke naam se, jiske naam ke saath koi cheez nuqsaan nahi de sakti.", count: 3, ref: "Sunan Abu Dawud 5088, Jami' Tirmidhi 3388" },
    { id: "e5", title: "Teen Qul", ar: "سورة الإخلاص، سورة الفلق، سورة الناس", ur: "Surah Ikhlas, Falaq aur Naas, teen teen martaba.", count: 3, ref: "Sunan Abu Dawud 5082, Jami' Tirmidhi 3575", quran: 112 },
    { id: "e6", title: "Tasbeeh", ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", ur: "SubhanAllahi wa bihamdihi, 100 martaba.", count: 100, ref: "Sahih Muslim 2692" }
  ]
};

/* ---------- Masnoon Duayein ---------- */
const DUAS = [
  { cat: "Sona / Jaagna", title: "Sone se pehle", ar: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", ur: "Aye Allah! Tere hi naam se marta (sota) hoon aur jeeta (jaagta) hoon.", ref: "Sahih Bukhari 6324" },
  { cat: "Sona / Jaagna", title: "Jaagne ke baad", ar: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", ur: "Tamaam tareef Allah ke liye jisne hamein maut (neend) ke baad zindagi di, aur usi ki taraf uthna hai.", ref: "Sahih Bukhari 6324" },
  { cat: "Khana", title: "Khane se pehle", ar: "بِسْمِ اللَّهِ", ur: "Allah ke naam se. (Bhool jayein to: Bismillahi awwalahu wa aakhirahu)", ref: "Sunan Abu Dawud 3767" },
  { cat: "Khana", title: "Khane ke baad", ar: "الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنِي هَذَا وَرَزَقَنِيهِ مِنْ غَيْرِ حَوْلٍ مِنِّي وَلَا قُوَّةٍ", ur: "Tamaam tareef Allah ke liye jisne mujhe yeh khilaya aur meri kisi taqat ke baghair mujhe yeh rizq diya.", ref: "Sunan Abu Dawud 4023, Jami' Tirmidhi 3458" },
  { cat: "Ghar / Safar", title: "Ghar se nikalte waqt", ar: "بِسْمِ اللَّهِ، تَوَكَّلْتُ عَلَى اللَّهِ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللَّهِ", ur: "Allah ke naam se, maine Allah par bharosa kiya, aur Allah ke siwa koi taqat aur quwwat nahi.", ref: "Sunan Abu Dawud 5095, Jami' Tirmidhi 3426" },
  { cat: "Ghar / Safar", title: "Safar / sawari par", ar: "سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ", ur: "Paak hai woh jisne isse hamare qaabu mein kiya, hum ise qaabu mein nahi kar sakte the, aur hum apne Rab ki taraf lautne wale hain.", ref: "Surah Az-Zukhruf 43:13-14, Sahih Muslim 1342" },
  { cat: "Masjid", title: "Masjid mein daakhil", ar: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ", ur: "Aye Allah! Mere liye apni rehmat ke darwaze khol de.", ref: "Sahih Muslim 713" },
  { cat: "Masjid", title: "Masjid se nikalte waqt", ar: "اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ", ur: "Aye Allah! Main tujhse tera fazl maangta hoon.", ref: "Sahih Muslim 713" },
  { cat: "Roz marrah", title: "Bait-ul-khala jaane se pehle", ar: "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبُثِ وَالْخَبَائِثِ", ur: "Aye Allah! Main naapak jinn mard aur aurton se teri panah maangta hoon.", ref: "Sahih Bukhari 142" },
  { cat: "Ramadan", title: "Iftar ke waqt", ar: "ذَهَبَ الظَّمَأُ وَابْتَلَّتِ الْعُرُوقُ وَثَبَتَ الْأَجْرُ إِنْ شَاءَ اللَّهُ", ur: "Pyaas chali gayi, ragein tar ho gayin, aur in sha Allah ajr saabit ho gaya.", ref: "Sunan Abu Dawud 2357" },
  { cat: "Ramadan", title: "Shab-e-Qadr ki dua", ar: "اللَّهُمَّ إِنَّكَ عَفُوٌّ تُحِبُّ الْعَفْوَ فَاعْفُ عَنِّي", ur: "Aye Allah! Tu bahut maaf karne wala hai, maafi ko pasand karta hai, to mujhe maaf farma de.", ref: "Jami' Tirmidhi 3513" },
  { cat: "Quran ki duayein", title: "Duniya aur aakhirat ki bhalai", ar: "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ", ur: "Aye hamare Rab! Hamein duniya mein bhi bhalai de aur aakhirat mein bhi, aur hamein aag ke azaab se bacha.", ref: "Surah Al-Baqarah 2:201" },
  { cat: "Quran ki duayein", title: "Ilm ki dua", ar: "رَّبِّ زِدْنِي عِلْمًا", ur: "Aye mere Rab! Mere ilm mein izafa farma.", ref: "Surah Ta-Ha 20:114" }
];

/* ---------- Tasbeeh presets ---------- */
const TASBEEH_PRESETS = [
  { id: "t1", name: "SubhanAllah", ar: "سُبْحَانَ اللَّهِ", target: 33 },
  { id: "t2", name: "Alhamdulillah", ar: "الْحَمْدُ لِلَّهِ", target: 33 },
  { id: "t3", name: "Allahu Akbar", ar: "اللَّهُ أَكْبَرُ", target: 34 },
  { id: "t4", name: "Astaghfirullah", ar: "أَسْتَغْفِرُ اللَّهَ", target: 100 },
  { id: "t5", name: "La ilaha illallah", ar: "لَا إِلَهَ إِلَّا اللَّهُ", target: 100 },
  { id: "t6", name: "SubhanAllahi wa bihamdihi", ar: "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ", target: 100 },
  { id: "t7", name: "Durood Shareef", ar: "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ", target: 100 }
];

/* ---------- 114 Surah (name, ayaat) ---------- */
const SURAHS = "Al-Fatiha:7|Al-Baqarah:286|Aal-e-Imran:200|An-Nisa:176|Al-Ma'idah:120|Al-An'am:165|Al-A'raf:206|Al-Anfal:75|At-Tawbah:129|Yunus:109|Hud:123|Yusuf:111|Ar-Ra'd:43|Ibrahim:52|Al-Hijr:99|An-Nahl:128|Al-Isra:111|Al-Kahf:110|Maryam:98|Ta-Ha:135|Al-Anbiya:112|Al-Hajj:78|Al-Mu'minun:118|An-Nur:64|Al-Furqan:77|Ash-Shu'ara:227|An-Naml:93|Al-Qasas:88|Al-Ankabut:69|Ar-Rum:60|Luqman:34|As-Sajdah:30|Al-Ahzab:73|Saba:54|Fatir:45|Ya-Sin:83|As-Saffat:182|Sad:88|Az-Zumar:75|Ghafir:85|Fussilat:54|Ash-Shura:53|Az-Zukhruf:89|Ad-Dukhan:59|Al-Jathiyah:37|Al-Ahqaf:35|Muhammad:38|Al-Fath:29|Al-Hujurat:18|Qaf:45|Adh-Dhariyat:60|At-Tur:49|An-Najm:62|Al-Qamar:55|Ar-Rahman:78|Al-Waqi'ah:96|Al-Hadid:29|Al-Mujadilah:22|Al-Hashr:24|Al-Mumtahanah:13|As-Saff:14|Al-Jumu'ah:11|Al-Munafiqun:11|At-Taghabun:18|At-Talaq:12|At-Tahrim:12|Al-Mulk:30|Al-Qalam:52|Al-Haqqah:52|Al-Ma'arij:44|Nuh:28|Al-Jinn:28|Al-Muzzammil:20|Al-Muddaththir:56|Al-Qiyamah:40|Al-Insan:31|Al-Mursalat:50|An-Naba:40|An-Nazi'at:46|Abasa:42|At-Takwir:29|Al-Infitar:19|Al-Mutaffifin:36|Al-Inshiqaq:25|Al-Buruj:22|At-Tariq:17|Al-A'la:19|Al-Ghashiyah:26|Al-Fajr:30|Al-Balad:20|Ash-Shams:15|Al-Layl:21|Ad-Duha:11|Ash-Sharh:8|At-Tin:8|Al-Alaq:19|Al-Qadr:5|Al-Bayyinah:8|Az-Zalzalah:8|Al-Adiyat:11|Al-Qari'ah:11|At-Takathur:8|Al-Asr:3|Al-Humazah:9|Al-Fil:5|Quraysh:4|Al-Ma'un:7|Al-Kawthar:3|Al-Kafirun:6|An-Nasr:3|Al-Masad:5|Al-Ikhlas:4|Al-Falaq:5|An-Nas:6"
  .split("|").map((s, i) => { const [n, a] = s.split(":"); return { no: i + 1, name: n, ayahs: +a }; });

/* ---------- 30 Para (naam, shuruaat surah:ayat) ---------- */
const PARAS = "Alif Lam Meem:1:1|Sayaqool:2:142|Tilkar Rusul:2:253|Lan Tanaloo:3:93|Wal Muhsanat:4:24|La Yuhibbullah:4:148|Wa Iza Sami'u:5:82|Wa Lau Annana:6:111|Qalal Mala'u:7:88|Wa'lamu:8:41|Ya'taziroon:9:93|Wa Ma Min Dabbah:11:6|Wa Ma Ubarri'u:12:53|Rubama:15:1|Subhanallazi:17:1|Qal Alam:18:75|Iqtaraba:21:1|Qad Aflaha:23:1|Wa Qalallazina:25:21|Amman Khalaq:27:56|Utlu Ma Oohiya:29:46|Wa Man Yaqnut:33:31|Wa Mali:36:28|Faman Azlamu:39:32|Ilaihi Yuraddu:41:47|Ha Meem:46:1|Qala Fama Khatbukum:51:31|Qad Sami Allah:58:1|Tabarakallazi:67:1|Amma Yatasa'aloon:78:1"
  .split("|").map((s, i) => { const [n, su, ay] = s.split(":"); return { no: i + 1, name: n, surah: +su, ayah: +ay }; });

/* ---------- Islamic dates (Hijri month-day) ---------- */
const ISLAMIC_DATES = [
  { m: 1, d: 1, title: "Naya Hijri Saal", note: "Islami saal ka aaghaz" },
  { m: 1, d: 9, title: "9 Muharram", note: "Ashura ke saath 9 ka roza bhi sunnat hai (Sahih Muslim 1134)" },
  { m: 1, d: 10, title: "Yaum-e-Ashura", note: "Ashura ka roza pichle saal ke gunahon ka kaffara (Sahih Muslim 1162)" },
  { m: 9, d: 1, title: "Ramadan Mubarak", note: "Roze shuru" },
  { m: 9, d: 21, title: "Aakhri Ashra shuru", note: "Taaq raaton mein Shab-e-Qadr talaash karein" },
  { m: 10, d: 1, title: "Eid-ul-Fitr", note: "Namaz se pehle sadqa-e-fitr ada karein" },
  { m: 12, d: 1, title: "Zul Hijjah ke 10 din", note: "Saal ke sabse afzal din (Sahih Bukhari 969)" },
  { m: 12, d: 9, title: "Yaum-e-Arafah", note: "Arafah ka roza do saal ke gunahon ka kaffara (Sahih Muslim 1162)" },
  { m: 12, d: 10, title: "Eid-ul-Adha", note: "Qurbani ka din" }
];

const HIJRI_MONTHS = ["Muharram", "Safar", "Rabi-ul-Awwal", "Rabi-us-Saani", "Jumada-al-Ula", "Jumada-al-Ukhra", "Rajab", "Shaban", "Ramadan", "Shawwal", "Zul Qadah", "Zul Hijjah"];

/* ---------- Shehar ---------- */
const CITIES = [
  { name: "Hyderabad", lat: 17.385, lng: 78.4867 },
  { name: "Secunderabad", lat: 17.4399, lng: 78.4983 },
  { name: "Warangal", lat: 17.9689, lng: 79.5941 },
  { name: "Karimnagar", lat: 18.4386, lng: 79.1288 },
  { name: "Nizamabad", lat: 18.6725, lng: 78.0941 },
  { name: "Kurnool", lat: 15.8281, lng: 78.0373 },
  { name: "Vijayawada", lat: 16.5062, lng: 80.648 },
  { name: "Bengaluru", lat: 12.9716, lng: 77.5946 },
  { name: "Chennai", lat: 13.0827, lng: 80.2707 },
  { name: "Mumbai", lat: 19.076, lng: 72.8777 },
  { name: "Pune", lat: 18.5204, lng: 73.8567 },
  { name: "Aurangabad", lat: 19.8762, lng: 75.3433 },
  { name: "Delhi", lat: 28.6139, lng: 77.209 },
  { name: "Lucknow", lat: 26.8467, lng: 80.9462 },
  { name: "Kolkata", lat: 22.5726, lng: 88.3639 },
  { name: "Bhopal", lat: 23.2599, lng: 77.4126 },
  { name: "Ahmedabad", lat: 23.0225, lng: 72.5714 },
  { name: "Patna", lat: 25.5941, lng: 85.1376 },
  { name: "Srinagar", lat: 34.0837, lng: 74.7973 },
  { name: "Kozhikode", lat: 11.2588, lng: 75.7804 }
];

/* ---------- Bachon ka checklist ---------- */
const KIDS_TASKS = [
  { id: "k1", label: "Fajr ki namaz", icon: "🌅" },
  { id: "k2", label: "Zuhr ki namaz", icon: "☀️" },
  { id: "k3", label: "Asr ki namaz", icon: "🌤️" },
  { id: "k4", label: "Maghrib ki namaz", icon: "🌇" },
  { id: "k5", label: "Isha ki namaz", icon: "🌙" },
  { id: "k6", label: "Quran / Qaida padha", icon: "📖" },
  { id: "k7", label: "Ek nayi dua yaad ki", icon: "🤲" },
  { id: "k8", label: "Sach bola", icon: "💬" },
  { id: "k9", label: "Ammi Abbu ki madad ki", icon: "❤️" },
  { id: "k10", label: "Bismillah se khana khaya", icon: "🍽️" }
];
