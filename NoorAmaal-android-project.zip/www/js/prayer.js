/* ============================================================
   Namaz ke auqaat — astronomical calculation (offline)
   Default: University of Islamic Sciences, Karachi (Fajr 18°, Isha 18°)
   Asr: Hanafi (saya 2 guna) ya Shafi (1 guna)
   ============================================================ */
const PrayerCalc = (() => {
  const dtr = d => d * Math.PI / 180, rtd = r => r * 180 / Math.PI;
  const sin = d => Math.sin(dtr(d)), cos = d => Math.cos(dtr(d)), tan = d => Math.tan(dtr(d));
  const asin = x => rtd(Math.asin(x)), acos = x => rtd(Math.acos(x)), atan2 = (y, x) => rtd(Math.atan2(y, x));
  const acot = x => rtd(Math.atan(1 / x));
  const fix = (a, b) => { a = a - b * Math.floor(a / b); return a < 0 ? a + b : a; };

  const METHODS = {
    karachi: { name: "Karachi (India mein aam)", fajr: 18, isha: 18 },
    mwl: { name: "Muslim World League", fajr: 18, isha: 17 },
    makkah: { name: "Umm al-Qura, Makkah", fajr: 18.5, ishaMin: 90 },
    isna: { name: "ISNA (America)", fajr: 15, isha: 15 }
  };

  function julian(y, m, d) {
    if (m <= 2) { y -= 1; m += 12; }
    const A = Math.floor(y / 100), B = 2 - A + Math.floor(A / 4);
    return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
  }
  function sunPos(jd) {
    const D = jd - 2451545.0;
    const g = fix(357.529 + 0.98560028 * D, 360);
    const q = fix(280.459 + 0.98564736 * D, 360);
    const L = fix(q + 1.915 * sin(g) + 0.020 * sin(2 * g), 360);
    const e = 23.439 - 0.00000036 * D;
    const RA = atan2(cos(e) * sin(L), cos(L)) / 15;
    const eqt = q / 15 - fix(RA, 24);
    const decl = asin(sin(e) * sin(L));
    return { decl, eqt };
  }

  /* returns times in local hours (decimal) */
  function compute(date, lat, lng, tz, opts = {}) {
    const method = METHODS[opts.method || "karachi"];
    const asrFactor = opts.asr === "shafi" ? 1 : 2;
    const jd = julian(date.getFullYear(), date.getMonth() + 1, date.getDate()) - lng / (15 * 24);

    const midDay = t => { const eqt = sunPos(jd + t).eqt; return fix(12 - eqt, 24); };
    const sunAngleTime = (angle, t, ccw) => {
      const decl = sunPos(jd + t).decl;
      const v = (-sin(angle) - sin(decl) * sin(lat)) / (cos(decl) * cos(lat));
      if (v < -1 || v > 1) return NaN;
      const T = acos(v) / 15;
      return midDay(t) + (ccw ? -T : T);
    };
    const asrTime = (factor, t) => {
      const decl = sunPos(jd + t).decl;
      const angle = -acot(factor + tan(Math.abs(lat - decl)));
      return sunAngleTime(angle, t);
    };

    let t = { fajr: 5, sunrise: 6, dhuhr: 12, asr: 13, maghrib: 18, isha: 18 };
    for (let i = 0; i < 2; i++) {
      const p = k => t[k] / 24;
      t = {
        fajr: sunAngleTime(method.fajr, p("fajr"), true),
        sunrise: sunAngleTime(0.833, p("sunrise"), true),
        dhuhr: midDay(p("dhuhr")),
        asr: asrTime(asrFactor, p("asr")),
        maghrib: sunAngleTime(0.833, p("maghrib")),
        isha: method.ishaMin ? NaN : sunAngleTime(method.isha, p("isha"))
      };
      if (method.ishaMin) t.isha = t.maghrib + method.ishaMin / 60;
    }
    const adj = tz - lng / 15;
    const out = {};
    for (const k in t) out[k] = t[k] + adj;
    out.dhuhr += 1 / 60; // zawal ke baad 1 minute ehtiyat
    const off = opts.offsets || {};
    for (const k in out) out[k] += (off[k] || 0) / 60;
    return out;
  }

  /* Convert decimal hours for a given date -> Date object */
  function toDate(date, hours) {
    const d = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
    return new Date(d.getTime() + Math.round(hours * 60) * 60000);
  }

  function qibla(lat, lng) {
    const kLat = 21.4225, kLng = 39.8262;
    const y = sin(kLng - lng);
    const x = cos(lat) * tan(kLat) - sin(lat) * cos(kLng - lng);
    return fix(atan2(y, x), 360);
  }

  return { compute, toDate, qibla, METHODS };
})();
