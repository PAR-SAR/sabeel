/* ============================================================
   NOOR AMAAL — App logic
   ============================================================ */
(() => {
"use strict";
const API = "https://api.alquran.cloud/v1";
const APP_VERSION = "1.0.0";
const $ = s => document.querySelector(s);
const appEl = $("#app");
const CAP = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() ? window.Capacitor : null;
const plugCache = {};
const Plug = n => {
  if (!CAP) return null;
  if (n in plugCache) return plugCache[n];
  try { plugCache[n] = CAP.isPluginAvailable(n) ? (CAP.Plugins[n] || CAP.registerPlugin(n)) : null; } catch (e) { plugCache[n] = null; }
  return plugCache[n];
};

/* ---------- Storage (safe) ---------- */
const mem = {};
const S = {
  get(k, d) { try { const v = localStorage.getItem("na:" + k); return v == null ? (k in mem ? mem[k] : d) : JSON.parse(v); } catch (e) { return k in mem ? mem[k] : d; } },
  set(k, v) { mem[k] = v; try { localStorage.setItem("na:" + k, JSON.stringify(v)); } catch (e) {} },
  del(k) { delete mem[k]; try { localStorage.removeItem("na:" + k); } catch (e) {} },
  keys(prefix) { const out = new Set(Object.keys(mem).filter(k => k.startsWith(prefix))); try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k.startsWith("na:" + prefix)) out.add(k.slice(3)); } } catch (e) {} return [...out]; }
};
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* ---------- Settings ---------- */
const DEF = {
  name: "", theme: "light", city: "Hyderabad", lat: 17.385, lng: 78.4867,
  method: "karachi", asr: "hanafi", hijriAdj: -1,
  offsets: { fajr: 0, sunrise: 0, dhuhr: 0, asr: 0, maghrib: 0, isha: 0 },
  ramadanForce: false, translation: "ur", qsize: 26,
  tsbDesign: "orb", tsbBg: "aurora", vibrate: true,
  remind: { on: false, azkaar: true, quran: true, quranTime: "21:00", namaz: false, ramadan: true }
};
let set = Object.assign({}, DEF, S.get("settings", {}));
set.offsets = Object.assign({}, DEF.offsets, set.offsets || {});
set.remind = Object.assign({}, DEF.remind, set.remind || {});
const saveSet = () => S.set("settings", set);

/* ---------- Theme ---------- */
const mq = window.matchMedia ? matchMedia("(prefers-color-scheme: dark)") : null;
function applyTheme() {
  const dark = set.theme === "dark" || (set.theme === "auto" && mq && mq.matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = dark ? "#07110E" : "#F3F7F5";
  const sb = Plug("StatusBar"); if (sb) { try { sb.setStyle({ style: dark ? "DARK" : "LIGHT" }); sb.setBackgroundColor({ color: dark ? "#07110E" : "#F3F7F5" }); } catch (e) {} }
}
if (mq && mq.addEventListener) mq.addEventListener("change", applyTheme);
applyTheme();

/* ---------- Dates ---------- */
const pad = n => String(n).padStart(2, "0");
const dkey = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const fromKey = k => { const [y, m, d] = k.split("-").map(Number); return new Date(y, m - 1, d); };
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const today = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const WD = ["Itwaar", "Peer", "Mangal", "Budh", "Jumeraat", "Jumma", "Hafta"];
const WDS = ["Itw", "Peer", "Mangal", "Budh", "Jumrat", "Jumma", "Hafta"];
const MO = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const MOF = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const fmtDate = d => `${d.getDate()} ${MO[d.getMonth()]}`;
const fmtTime = dt => { if (!dt || isNaN(dt)) return "--:--"; let h = dt.getHours(); const m = pad(dt.getMinutes()); const ap = h >= 12 ? "PM" : "AM"; h = h % 12 || 12; return `${h}:${m} ${ap}`; };
const fmtTimeShort = dt => { if (!dt || isNaN(dt)) return "--"; let h = dt.getHours() % 12 || 12; return `${h}:${pad(dt.getMinutes())}`; };
const dayIndex = d => Math.floor((Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())) / 864e5);

/* Hijri */
let hijriFmt = null;
for (const cal of ["islamic-umalqura", "islamic-civil", "islamic"]) {
  try { const f = new Intl.DateTimeFormat("en-u-ca-" + cal, { day: "numeric", month: "numeric", year: "numeric" }); const p = f.formatToParts(new Date()); if (p.find(x => x.type === "month")) { hijriFmt = f; break; } } catch (e) {}
}
function hijriArith(date) { // Kuwaiti algorithm fallback
  const jd = Math.floor((date.getTime() / 864e5) + 2440587.5) + 0.5;
  const l0 = Math.floor(jd) - 1948440 + 10632, n = Math.floor((l0 - 1) / 10631), l = l0 - 10631 * n + 354;
  const j = Math.floor((10985 - l) / 5316) * Math.floor((50 * l) / 17719) + Math.floor(l / 5670) * Math.floor((43 * l) / 15238);
  const l2 = l - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;
  const m = Math.floor((24 * l2) / 709), d = l2 - Math.floor((709 * m) / 24), y = 30 * n + j - 30;
  return { d, m, y };
}
const hCache = {};
function hijri(date) {
  const x = addDays(date, set.hijriAdj || 0); x.setHours(12);
  const k = dkey(x); if (hCache[k]) return hCache[k];
  let r;
  if (hijriFmt) { const p = hijriFmt.formatToParts(x); r = { d: +p.find(a => a.type === "day").value, m: +p.find(a => a.type === "month").value, y: parseInt(p.find(a => a.type === "year").value) }; }
  else r = hijriArith(x);
  return (hCache[k] = r);
}
const hijriStr = h => `${h.d} ${HIJRI_MONTHS[h.m - 1]} ${h.y}`;
const isRamadan = (d = today()) => hijri(d).m === 9 || set.ramadanForce;
function ramadanStart(from = today()) {
  const h = hijri(from);
  if (h.m === 9) return addDays(from, -(h.d - 1));
  for (let i = 1; i < 400; i++) { const d = addDays(from, i); const hh = hijri(d); if (hh.m === 9 && hh.d === 1) return d; }
  return null;
}
const ramadanDay = (d = today()) => { const h = hijri(d); if (h.m === 9) return h.d; return set.ramadanForce ? 1 : 0; };

/* ---------- Prayer times ---------- */
const PR = [["fajr", "Fajr"], ["sunrise", "Tulu"], ["dhuhr", "Zuhr"], ["asr", "Asr"], ["maghrib", "Maghrib"], ["isha", "Isha"]];
const PR5 = [["fajr", "Fajr", "🌅"], ["dhuhr", "Zuhr", "☀️"], ["asr", "Asr", "🌤️"], ["maghrib", "Maghrib", "🌇"], ["isha", "Isha", "🌙"]];
const tCache = {};
function times(date) {
  const k = dkey(date) + set.lat + set.lng + set.method + set.asr + JSON.stringify(set.offsets);
  if (tCache[k]) return tCache[k];
  const tz = -new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12).getTimezoneOffset() / 60;
  const t = PrayerCalc.compute(date, set.lat, set.lng, tz, { method: set.method, asr: set.asr, offsets: set.offsets });
  const o = {}; for (const key in t) o[key] = PrayerCalc.toDate(date, t[key]);
  return (tCache[k] = o);
}
function nextPrayer(now = new Date()) {
  const t = times(today());
  for (const [k, n] of PR5) if (t[k] > now) return { key: k, name: n, at: t[k] };
  const tm = times(addDays(today(), 1)); return { key: "fajr", name: "Fajr", at: tm.fajr, tomorrow: true };
}
function currentPrayerKey(now = new Date()) {
  const t = times(today()); let cur = "isha";
  if (now < t.fajr) return "isha";
  for (const [k] of PR) if (t[k] <= now) cur = k;
  return cur;
}
const cdText = ms => { if (ms < 0) ms = 0; const s = Math.floor(ms / 1000), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60; return h > 0 ? `${h}h ${pad(m)}m ${pad(sec)}s` : `${m}m ${pad(sec)}s`; };

/* ---------- Day data ---------- */
const getDay = k => S.get("day:" + k, {});
const setDay = (k, v) => S.set("day:" + k, v);
const qaza = () => S.get("qaza", { namaz: 0, roza: 0 });
function dayScore(k) {
  const d = getDay(k), date = fromKey(k); const p = d.p || {};
  let done = 0, total = 0;
  PR5.forEach(([x]) => { total++; if (p[x] === "j" || p[x] === "a") done++; });
  total += 3; if (d.azM) done++; if (d.azE) done++; if ((d.qp || 0) > 0) done++;
  if (isRamadanDate(date)) { total += 2; if (d.roza === "r") done++; if ((d.tar || 0) > 0) done++; }
  return { done, total, pct: Math.round(done / total * 100), namaz: PR5.filter(([x]) => p[x] === "j" || p[x] === "a").length, jamaat: PR5.filter(([x]) => p[x] === "j").length };
}
const isRamadanDate = date => hijri(date).m === 9 || (set.ramadanForce && dkey(date) === dkey(today()));

/* ---------- Helpers: haptic, share, toast ---------- */
function vib(ms = 12) {
  if (!set.vibrate) return;
  const H = Plug("Haptics");
  if (H) { try { ms > 60 ? H.vibrate({ duration: ms }) : H.impact({ style: "LIGHT" }); return; } catch (e) {} }
  try { navigator.vibrate && navigator.vibrate(ms); } catch (e) {}
}
let toastT;
function toast(msg) { const t = $("#toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove("show"), 2200); }
async function share(text, title = APP_NAME) {
  const full = text + `\n\n— ${APP_NAME} app`;
  const SP = Plug("Share");
  try { if (SP) { await SP.share({ title, text: full, dialogTitle: "Share karein" }); return; } } catch (e) { return; }
  try { if (navigator.share) { await navigator.share({ title, text: full }); return; } } catch (e) { return; }
  try { await navigator.clipboard.writeText(full); toast("Copy ho gaya ✓ ab WhatsApp pe paste karein"); }
  catch (e) { const ta = document.createElement("textarea"); ta.value = full; document.body.appendChild(ta); ta.select(); try { document.execCommand("copy"); toast("Copy ho gaya ✓"); } catch (_) {} ta.remove(); }
}
function confetti() {
  const box = document.createElement("div"); box.className = "confetti"; document.body.appendChild(box);
  const cols = ["#14B88A", "#F2C94C", "#0B8F6A", "#5EEAD4", "#E6C163"];
  for (let i = 0; i < 46; i++) {
    const s = document.createElement("span");
    const size = 6 + Math.random() * 7;
    s.style.cssText = `position:absolute;left:50%;top:40%;width:${size}px;height:${size * (Math.random() > .5 ? 1 : 2)}px;background:${cols[i % cols.length]};border-radius:${Math.random() > .5 ? "50%" : "2px"}`;
    box.appendChild(s);
    const a = Math.random() * Math.PI * 2, r = 120 + Math.random() * 220;
    s.animate([{ transform: "translate(0,0) rotate(0)", opacity: 1 }, { transform: `translate(${Math.cos(a) * r}px,${Math.sin(a) * r + 200}px) rotate(${Math.random() * 720}deg)`, opacity: 0 }], { duration: 1300 + Math.random() * 700, easing: "cubic-bezier(.2,.7,.3,1)", fill: "forwards" });
  }
  setTimeout(() => box.remove(), 2200);
}

/* ---------- Icons ---------- */
const I = (p, extra = "") => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${extra}>${p}</svg>`;
const IC = {
  home: I('<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>'),
  check: I('<path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"/>'),
  book: I('<path d="M12 6c-2-1.5-5-2-8-1.5v14c3-.5 6 0 8 1.5 2-1.5 5-2 8-1.5v-14c-3-.5-6 0-8 1.5z"/><path d="M12 6v14"/>'),
  beads: I('<circle cx="12" cy="5" r="2"/><circle cx="17" cy="8" r="2"/><circle cx="7" cy="8" r="2"/><circle cx="18" cy="14" r="2"/><circle cx="6" cy="14" r="2"/><path d="M12 15v6"/><circle cx="12" cy="13" r="1.6"/>'),
  grid: I('<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>'),
  back: I('<path d="M15 18l-6-6 6-6"/>'),
  next: I('<path d="M9 18l6-6-6-6"/>'),
  share: I('<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>'),
  play: I('<path d="M7 4.5v15l12-7.5z" fill="currentColor"/>'),
  pause: I('<rect x="6" y="5" width="4" height="14" rx="1" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1" fill="currentColor"/>'),
  stop: I('<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/>'),
  mark: I('<path d="M6 3h12v18l-6-4-6 4z"/>'),
  markF: I('<path d="M6 3h12v18l-6-4-6 4z" fill="currentColor"/>'),
  gear: I('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>'),
  undo: I('<path d="M9 14L4 9l5-5"/><path d="M4 9h11a5 5 0 0 1 0 10h-3"/>'),
  reset: I('<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>'),
  list: I('<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>'),
  palette: I('<circle cx="13.5" cy="6.5" r="1.5"/><circle cx="17.5" cy="10.5" r="1.5"/><circle cx="8.5" cy="7.5" r="1.5"/><circle cx="6.5" cy="12.5" r="1.5"/><path d="M12 2a10 10 0 0 0 0 20c1 0 1.7-.8 1.7-1.7 0-.5-.2-.9-.5-1.2-.3-.3-.5-.7-.5-1.2 0-.9.8-1.7 1.7-1.7H16a6 6 0 0 0 6-6C22 6 17.5 2 12 2z"/>'),
  plus: I('<path d="M12 5v14M5 12h14"/>'),
  trash: I('<path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6"/>'),
  search: I('<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>'),
  loc: I('<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>'),
  tick: I('<path d="M5 12l5 5L20 7"/>', 'stroke-width="3"')
};
const moonSVG = `<svg class="moon" viewBox="0 0 64 64"><defs><radialGradient id="mg" cx="35%" cy="35%"><stop offset="0" stop-color="#FFF8DC"/><stop offset="1" stop-color="#F2D27A"/></radialGradient></defs><path d="M40 6a26 26 0 1 0 18 44A22 22 0 1 1 40 6z" fill="url(#mg)" opacity=".95"/><path d="M50 14l1.6 3.4 3.4 1.6-3.4 1.6L50 24l-1.6-3.4-3.4-1.6 3.4-1.6z" fill="#fff"/></svg>`;
const ring = (pct, size = 86, label) => { const r = (size - 12) / 2, c = 2 * Math.PI * r; return `<div class="ring" style="width:${size}px;height:${size}px"><svg width="${size}" height="${size}"><circle class="bg" cx="${size / 2}" cy="${size / 2}" r="${r}"/><circle class="fg" cx="${size / 2}" cy="${size / 2}" r="${r}" stroke-dasharray="${c}" stroke-dashoffset="${c * (1 - pct / 100)}"/></svg><div class="val">${label != null ? label : pct + "%"}</div></div>`; };
const checkBox = on => `<span class="check ${on ? "on" : ""}">${IC.tick}</span>`;

/* ---------- Router ---------- */
const st = { tab: "home", stack: [], root: {} };
const cur = () => st.stack.length ? st.stack[st.stack.length - 1] : { page: st.tab, params: (st.root[st.tab] = st.root[st.tab] || {}) };
function go(page, params = {}) { st.stack.push({ page, params }); try { history.pushState({ d: st.stack.length }, ""); } catch (e) {} render(true); }
function back() { if (st.stack.length) { st.stack.pop(); render(true); return true; } if (st.tab !== "home") { setTab("home"); return true; } return false; }
function setTab(t) { stopAudio(); st.tab = t; st.stack = []; if (t === "amaal") st.root.amaal = {}; render(true); }
window.addEventListener("popstate", () => { if (!back()) {} });
const AppP = Plug("App");
if (AppP) { AppP.addListener("backButton", () => { if (!closeSheet() && !back()) AppP.exitApp(); }); AppP.addListener("resume", () => { render(); scheduleReminders(); }); }

/* ---------- Sheet ---------- */
function openSheet(html) { $("#sheet").innerHTML = `<div class="grab"></div>` + html; $("#sheet").classList.add("show"); $("#sheetBg").classList.add("show"); }
function closeSheet() { const s = $("#sheet"); if (!s.classList.contains("show")) return false; s.classList.remove("show"); $("#sheetBg").classList.remove("show"); return true; }

/* ---------- Render ---------- */
function header(title, sub, opts = {}) {
  const isSub = st.stack.length > 0;
  return `<div class="top">${isSub ? `<div class="back"><button class="icon-btn" data-a="back" aria-label="Wapas">${IC.back}</button><div><h1>${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ""}</div></div>` : `<div><h1>${title}</h1>${sub ? `<div class="sub">${sub}</div>` : ""}</div>`}${opts.right || ""}</div>`;
}
function render(scrollTop) {
  const c = cur();
  const fn = PAGES[c.page] || PAGES.home;
  appEl.innerHTML = `<div class="fade-in">${fn(c.params || {})}</div>`;
  document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("on", b.dataset.tab === st.tab));
  if (scrollTop) window.scrollTo(0, 0);
  const after = AFTER[c.page]; if (after) after(c.params || {});
}
const AFTER = {};

/* ============================================================
   PAGES
   ============================================================ */
const PAGES = {};

/* ---------- HOME ---------- */
PAGES.home = () => {
  const now = new Date(), td = today(), h = hijri(td), t = times(td), k = dkey(td);
  const greet = `Assalamu Alaikum${set.name ? ", " + esc(set.name) : ""}`;
  const sub = `${WD[td.getDay()]}, ${fmtDate(td)} · ${hijriStr(h)}`;
  const ram = isRamadan(td);
  let hero;
  if (ram) {
    const sehriEnd = t.fajr, iftar = t.maghrib;
    let label, target;
    if (now < sehriEnd) { label = "Sehri khatam hone mein"; target = sehriEnd; }
    else if (now < iftar) { label = "Iftar mein"; target = iftar; }
    else { const tm = times(addDays(td, 1)); label = "Kal ki Sehri khatam hone mein"; target = tm.fajr; }
    hero = `<div class="card hero">${moonSVG}<div class="label">🌙 Ramadan ${ramadanDay(td)} · ${esc(set.city)}</div><div class="label" style="margin-top:10px">${label}</div><div class="big" data-cd="${target.getTime()}">${cdText(target - now)}</div>
      <div class="hero-split"><div><span>Sehri khatam (Fajr)</span><b>${fmtTime(sehriEnd)}</b></div><div><span>Iftar (Maghrib)</span><b>${fmtTime(iftar)}</b></div></div></div>`;
  } else {
    const np = nextPrayer(now);
    hero = `<div class="card hero">${moonSVG}<div class="label">Agli namaz · ${esc(set.city)}</div><div class="big">${np.name}</div><div style="font-size:18px;font-weight:500">${fmtTime(np.at)}${np.tomorrow ? " (kal)" : ""}</div><div class="count" style="margin-top:8px">⏳ <span data-cd="${np.at.getTime()}">${cdText(np.at - now)}</span> baqi</div></div>`;
  }
  const curK = currentPrayerKey(now);
  const strip = `<div class="card"><div class="prayers">${PR.map(([key, n]) => `<div class="pr ${key === curK ? "now" : ""}"><div class="n">${n}</div><div class="t">${fmtTimeShort(t[key])}</div></div>`).join("")}</div></div>`;

  // banners
  let banners = "";
  const wd = td.getDay();
  if (wd === 5) banners += `<div class="banner" data-a="openSurah" data-n="18"><div class="em">🕌</div><div><b>Aaj Jumma Mubarak!</b><span>Surah Kahf padhein aur kasrat se Durood bhejein. Tap karein →</span></div></div>`;
  if (wd === 0 || wd === 3) banners += `<div class="banner"><div class="em">🌙</div><div><b>Kal ${wd === 0 ? "Peer" : "Jumeraat"} hai</b><span>Sunnat roze ki niyyat kar lein (Tirmidhi 747)</span></div></div>`;
  if (h.d === 12 && h.m !== 9) banners += `<div class="banner"><div class="em">🌕</div><div><b>Kal se Ayyam-ul-Beedh</b><span>13, 14, 15 tareekh ke sunnat roze</span></div></div>`;
  if ([13, 14, 15].includes(h.d) && h.m !== 9) banners += `<div class="banner"><div class="em">🌕</div><div><b>Ayyam-ul-Beedh (${h.d} ${HIJRI_MONTHS[h.m - 1]})</b><span>Aaj sunnat roza ka din hai</span></div></div>`;
  const ev = ISLAMIC_DATES.find(e => e.m === h.m && e.d === h.d);
  if (ev) banners += `<div class="banner"><div class="em">✨</div><div><b>${ev.title}</b><span>${ev.note}</span></div></div>`;

  let ramCard = "";
  if (!ram) {
    const rs = ramadanStart(td);
    if (rs) { const days = Math.round((rs - td) / 864e5); ramCard = `<div class="card" data-a="go" data-p="ramadan" style="cursor:pointer"><div class="row between"><div><div class="muted small">Ramadan ${hijri(rs).y} ki tayyari</div><div style="font-size:26px;font-weight:600;margin-top:2px">${days} din baqi</div><div class="muted small">Andaazan ${fmtDate(rs)} ${rs.getFullYear()} · chaand par depend</div></div><div style="font-size:42px">🌙</div></div></div>`; }
  } else {
    ramCard = `<div class="tiles" style="margin-bottom:14px"><button class="tile" data-a="go" data-p="ramadan"><span class="ti g">🌙</span>Ramadan</button><button class="tile" data-a="go" data-p="timetable"><span class="ti">🕰️</span>Timetable</button><button class="tile" data-a="go" data-p="khatam"><span class="ti">📖</span>Khatam</button></div>`;
  }

  const sc = dayScore(k), d = getDay(k), p = d.p || {};
  const progress = `<div class="card"><div class="row" style="gap:16px">${ring(sc.pct)}<div style="flex:1"><h3 style="margin:0 0 4px">Aaj ke Amaal</h3><div class="muted small">${sc.done} / ${sc.total} mukammal · namaz ${sc.namaz}/5</div><button class="btn sm" style="margin-top:10px" data-a="tab" data-t="amaal">Poora checklist ${IC.next}</button></div></div>
    <div class="ticks" style="margin-top:14px">${PR5.map(([x, n, e]) => `<button class="tick ${p[x] === "j" || p[x] === "a" ? "done" : p[x] === "q" ? "miss" : ""}" data-a="quickNamaz" data-k="${x}"><span class="ic">${e}</span>${n}</button>`).join("")}</div></div>`;

  const isMorning = now < t.asr;
  const azK = isMorning ? "azM" : "azE";
  const azCard = `<div class="card" data-a="go" data-p="azkaar" data-type="${isMorning ? "morning" : "evening"}" style="cursor:pointer"><div class="row"><div class="li-ico" style="font-size:30px">${isMorning ? "🌄" : "🌆"}</div><div style="flex:1"><b>${isMorning ? "Subah" : "Shaam"} ke Azkaar</b><div class="muted small">${d[azK] ? "Mukammal ✓ MashaAllah" : "Abhi padhein, sirf 5 minute"}</div></div>${d[azK] ? `<span class="tag">✓ Done</span>` : `<span class="tag gold">Shuru karein</span>`}</div></div>`;

  const di = dayIndex(td);
  const ay = AYAT[di % AYAT.length], hd = HADITH[(di + 3) % HADITH.length], ns = NASEEHAT[(di + 7) % NASEEHAT.length];
  const daily = `
    <div class="sec-title">Aaj ki Roshni</div>
    <div class="card daily"><span class="quote-mark">۞</span><h3>📖 Aaj ki Ayat</h3><div class="ar">${ay.ar}</div><div class="tr">${esc(ay.ur)}</div><div class="ref">${ay.ref}</div><div class="actions"><button class="btn sm" data-a="share" data-text="${esc(ay.ar + "\n\n" + ay.ur + "\n(" + ay.ref + ")")}">${IC.share} Share</button></div></div>
    <div class="card daily"><span class="quote-mark">❝</span><h3>🌿 Aaj ki Hadith</h3><div class="tr">${esc(hd.text)}</div><div class="ref">${hd.ref}</div><div class="actions"><button class="btn sm" data-a="share" data-text="${esc("Rasoolullah ﷺ ne farmaya: " + hd.text + "\n(" + hd.ref + ")")}">${IC.share} Share</button></div></div>
    <div class="card daily" style="background:var(--accent-soft);border-color:rgba(185,138,31,.18)"><h3>💡 Aaj ki Naseehat</h3><div class="tr">${esc(ns)}</div></div>`;

  const lr = S.get("lastRead");
  const tiles = `<div class="sec-title">Jaldi pahunchein</div><div class="tiles">
    <button class="tile" data-a="${lr ? "openSurah" : "tab"}" data-t="quran" data-n="${lr ? lr.s : ""}" data-ayah="${lr ? lr.a : ""}"><span class="ti">📖</span>${lr ? "Quran jaari" : "Quran"}</button>
    <button class="tile" data-a="tab" data-t="tasbeeh"><span class="ti g">📿</span>Tasbeeh</button>
    <button class="tile" data-a="go" data-p="qibla"><span class="ti">🧭</span>Qibla</button>
    <button class="tile" data-a="go" data-p="duas"><span class="ti g">🤲</span>Duayein</button>
    <button class="tile" data-a="go" data-p="ramadan"><span class="ti">🌙</span>Ramadan</button>
    <button class="tile" data-a="go" data-p="kids"><span class="ti g">⭐</span>Bachon ka</button></div>`;

  return header(greet, sub, { right: `<button class="icon-btn" data-a="go" data-p="settings" aria-label="Settings">${IC.gear}</button>` }) + hero + strip + banners + ramCard + progress + azCard + daily + tiles;
};

/* ---------- AMAAL ---------- */
PAGES.amaal = (pr) => {
  const td = today();
  const date = pr.date ? fromKey(pr.date) : td;
  const k = dkey(date), d = getDay(k), p = d.p || {}, sc = dayScore(k), h = hijri(date);
  const isToday = k === dkey(td);
  const nav = `<div class="card" style="padding:10px 12px"><div class="row between"><button class="icon-btn" data-a="amaalDay" data-o="-1">${IC.back}</button><div style="text-align:center"><b>${isToday ? "Aaj" : WD[date.getDay()]}, ${fmtDate(date)}</b><div class="muted small">${hijriStr(h)}</div></div><button class="icon-btn" data-a="amaalDay" data-o="1" ${isToday ? 'style="opacity:.3;pointer-events:none"' : ""}>${IC.next}</button></div></div>`;
  const top = `<div class="card"><div class="row" style="gap:16px">${ring(sc.pct, 96)}<div style="flex:1"><div style="font-size:18px;font-weight:600">${sc.pct >= 100 ? "MashaAllah! 🌟" : sc.pct >= 60 ? "Bahut khoob! 👏" : sc.pct > 0 ? "Achhi shuruaat" : "Bismillah karein"}</div><div class="muted small">${sc.done} / ${sc.total} amaal mukammal</div><button class="btn sm" style="margin-top:10px" data-a="go" data-p="report">📊 Monthly Report</button></div></div></div>`;
  const seg = (key, val) => `<div class="seg"><button class="${val === "j" ? "on" : ""}" data-a="namaz" data-k="${key}" data-v="j" data-d="${k}">Jamaat</button><button class="${val === "a" ? "on" : ""}" data-a="namaz" data-k="${key}" data-v="a" data-d="${k}">Akele</button><button class="${val === "q" ? "on m" : ""}" data-a="namaz" data-k="${key}" data-v="q" data-d="${k}">Chhooti</button></div>`;
  const t = times(date);
  const namaz = `<div class="card"><h3>🕌 Farz Namaz <span class="tag">${sc.namaz}/5</span></h3><div class="list">${PR5.map(([x, n, e]) => `<div class="li"><div class="ico">${e}</div><div class="lt"><b>${n}</b><span>${fmtTime(t[x])}</span></div>${seg(x, p[x])}</div>`).join("")}</div></div>`;
  const tog = (key, label, sub, icon) => `<div class="li" data-a="toggleDay" data-k="${key}" data-d="${k}" style="cursor:pointer"><div class="ico">${icon}</div><div class="lt"><b>${label}</b>${sub ? `<span>${sub}</span>` : ""}</div>${checkBox(d[key])}</div>`;
  const nafl = `<div class="card"><h3>✨ Sunnat / Nafl</h3><div class="list">${tog("witr", "Witr", "Isha ke baad", "🌌")}${tog("tah", "Tahajjud", "Raat ka aakhri hissa", "🌠")}${tog("ish", "Ishraq / Chasht", "Suraj nikalne ke baad", "🌤️")}</div></div>`;
  const zikr = `<div class="card"><h3>📿 Zikr, Quran aur Sadqa</h3><div class="list">${tog("azM", "Subah ke Azkaar", "", "🌄")}${tog("azE", "Shaam ke Azkaar", "", "🌆")}
    <div class="li"><div class="ico">📖</div><div class="lt"><b>Quran tilawat</b><span>Kitne page padhe</span></div><div class="stepper"><button data-a="qp" data-o="-1" data-d="${k}">−</button><span class="v">${d.qp || 0}</span><button data-a="qp" data-o="1" data-d="${k}">+</button></div></div>
    ${tog("sadqa", "Sadqa", "Chahe thoda sa ho", "💝")}${tog("durood", "Durood Shareef", "", "🌹")}${tog("walidain", "Walidain ki khidmat", "", "❤️")}</div></div>`;
  let ram = "";
  if (isRamadanDate(date)) {
    ram = `<div class="card" style="border-color:rgba(185,138,31,.3)"><h3>🌙 Ramadan <span class="tag gold">Roza ${hijri(date).m === 9 ? hijri(date).d : ramadanDay()}</span></h3><div class="list">
      <div class="li"><div class="ico">🌙</div><div class="lt"><b>Roza</b></div><div class="seg"><button class="${d.roza === "r" ? "on" : ""}" data-a="roza" data-v="r" data-d="${k}">Rakha</button><button class="${d.roza === "q" ? "on m" : ""}" data-a="roza" data-v="q" data-d="${k}">Qaza</button></div></div>
      <div class="li"><div class="ico">🕌</div><div class="lt"><b>Taraweeh</b><span>Rakat</span></div><div class="seg">${[0, 8, 20].map(v => `<button class="${(d.tar || 0) === v ? "on" : ""}" data-a="tar" data-v="${v}" data-d="${k}">${v || "Nahi"}</button>`).join("")}</div></div>
      ${tog("sehri", "Sehri ki", "Sunnat aur barkat", "🍽️")}${tog("iftarKaraya", "Kisi ka roza iftar karaya", "", "🤝")}</div></div>`;
  }
  const custom = S.get("customAmaal", []);
  const cus = `<div class="card"><h3>🎯 Mere Amaal <button class="btn sm tag" style="margin-left:auto" data-a="addCustom">${IC.plus} Jodein</button></h3>${custom.length ? `<div class="list">${custom.map(c => `<div class="li"><div class="lt" data-a="toggleCustom" data-id="${c.id}" data-d="${k}" style="cursor:pointer"><b>${esc(c.label)}</b></div><button class="mini-btn" data-a="delCustom" data-id="${c.id}">${IC.trash}</button><span data-a="toggleCustom" data-id="${c.id}" data-d="${k}" style="cursor:pointer">${checkBox((d.c || {})[c.id])}</span></div>`).join("")}</div>` : `<div class="muted small">Apna koi bhi amal jodein, jaise "Surah Mulk", "Istighfar 100", "Kisi ki madad".</div>`}</div>`;
  const q = qaza();
  const qz = `<div class="card"><h3>📋 Qaza ka Hisaab</h3><div class="muted small" style="margin-bottom:6px">"Chhooti" chunne par namaz apne aap yahan jud jaati hai. Ada karne par kam karein.</div><div class="list">
    <div class="li"><div class="lt"><b>Qaza namaz baqi</b></div><div class="stepper"><button data-a="qaza" data-k="namaz" data-o="-1">−</button><span class="v">${q.namaz}</span><button data-a="qaza" data-k="namaz" data-o="1">+</button></div></div>
    <div class="li"><div class="lt"><b>Qaza roze baqi</b></div><div class="stepper"><button data-a="qaza" data-k="roza" data-o="-1">−</button><span class="v">${q.roza}</span><button data-a="qaza" data-k="roza" data-o="1">+</button></div></div></div></div>`;
  return header("Amaal Tracker", "Roz ka hisaab, apne liye") + nav + top + namaz + ram + zikr + nafl + cus + qz;
};

/* ---------- REPORT ---------- */
function allDayKeys() { return S.keys("day:").map(k => k.slice(4)).sort(); }
function streaks() {
  const full = k => dayScore(k).namaz === 5;
  let curS = 0, d = today();
  if (!full(dkey(d))) d = addDays(d, -1);
  while (full(dkey(d)) && curS < 3650) { curS++; d = addDays(d, -1); }
  let best = 0, run = 0, prev = null;
  for (const k of allDayKeys()) { if (full(k)) { run = prev && (fromKey(k) - fromKey(prev)) / 864e5 === 1 && full(prev) ? run + 1 : 1; best = Math.max(best, run); } else run = 0; prev = k; }
  return { cur: curS, best: Math.max(best, curS) };
}
PAGES.report = (pr) => {
  const base = pr.m ? new Date(pr.y, pr.m, 1) : new Date(today().getFullYear(), today().getMonth(), 1);
  const y = base.getFullYear(), m = base.getMonth(), daysIn = new Date(y, m + 1, 0).getDate();
  const first = new Date(y, m, 1).getDay();
  let cells = ["I", "P", "M", "B", "J", "J", "H"].map(x => `<div class="h">${x}</div>`).join("");
  for (let i = 0; i < first; i++) cells += `<div class="d empty"></div>`;
  let tot = { pct: 0, n: 0, namaz: 0, jamaat: 0, qp: 0, az: 0, roza: 0, tsb: 0 };
  const tdk = dkey(today());
  for (let i = 1; i <= daysIn; i++) {
    const k = `${y}-${pad(m + 1)}-${pad(i)}`, d = getDay(k), has = Object.keys(d).length > 0;
    let lv = 0;
    if (has) { const sc = dayScore(k); lv = sc.pct >= 90 ? 4 : sc.pct >= 60 ? 3 : sc.pct >= 30 ? 2 : sc.pct > 0 ? 1 : 0; tot.pct += sc.pct; tot.n++; tot.namaz += sc.namaz; tot.jamaat += sc.jamaat; tot.qp += d.qp || 0; tot.az += (d.azM ? 1 : 0) + (d.azE ? 1 : 0); tot.roza += d.roza === "r" ? 1 : 0; tot.tsb += d.tsb || 0; }
    cells += `<div class="d l${lv} ${k === tdk ? "today" : ""}">${i}</div>`;
  }
  const sk = streaks();
  const avg = tot.n ? Math.round(tot.pct / tot.n) : 0;
  const bd = badges();
  return header("Monthly Report", "Apni progress dekhein") +
    `<div class="card"><div class="row between" style="margin-bottom:12px"><button class="icon-btn" data-a="repMonth" data-y="${m === 0 ? y - 1 : y}" data-m="${m === 0 ? 11 : m - 1}">${IC.back}</button><b style="font-size:16px">${MOF[m]} ${y}</b><button class="icon-btn" data-a="repMonth" data-y="${m === 11 ? y + 1 : y}" data-m="${m === 11 ? 0 : m + 1}">${IC.next}</button></div><div class="cal">${cells}</div>
    <div class="row small muted" style="justify-content:center;margin-top:12px;gap:6px">Kam <span class="cal" style="display:flex;gap:4px">${[0, 1, 2, 3, 4].map(l => `<span class="d l${l}" style="width:14px;height:14px;border-radius:4px"></span>`).join("")}</span> Zyada</div></div>
    <div class="grid2" style="margin-bottom:14px"><div class="stat"><b>${avg}%</b><span>Ausat score</span></div><div class="stat"><b>🔥 ${sk.cur}</b><span>Namaz streak (best ${sk.best})</span></div><div class="stat"><b>${tot.namaz}</b><span>Namazein (${tot.jamaat} jamaat)</span></div><div class="stat"><b>${tot.qp}</b><span>Quran ke page</span></div><div class="stat"><b>${tot.az}</b><span>Azkaar sessions</span></div><div class="stat"><b>${tot.tsb.toLocaleString()}</b><span>Tasbeeh</span></div>${tot.roza ? `<div class="stat"><b>${tot.roza}</b><span>Roze</span></div>` : ""}</div>
    <div class="card"><h3>🏆 Badges <span class="tag gold">${bd.filter(b => b.got).length}/${bd.length}</span></h3><div class="badges">${bd.map(b => `<div class="badge ${b.got ? "got" : ""}"><span class="b">${b.e}</span>${b.t}</div>`).join("")}</div></div>
    <button class="btn block ghost" data-a="shareReport" data-txt="${esc(`Mera ${MOF[m]} ka hisaab (${APP_NAME}):\n🕌 Namazein: ${tot.namaz}\n📖 Quran page: ${tot.qp}\n📿 Tasbeeh: ${tot.tsb}\n🔥 Streak: ${sk.cur} din`)}">${IC.share} Report share karein</button>`;
};
function badges() {
  const keys = allDayKeys(); let qp = 0, roza = 0;
  keys.forEach(k => { const d = getDay(k); qp += d.qp || 0; roza += d.roza === "r" ? 1 : 0; });
  const sk = streaks(), tsb = S.get("tsb", {}).total || 0, kh = (S.get("khatam", {}).paras || []).filter(Boolean).length;
  return [
    { e: "🌱", t: "Pehla qadam", got: keys.length > 0 },
    { e: "🔥", t: "3 din streak", got: sk.best >= 3 },
    { e: "🏅", t: "7 din streak", got: sk.best >= 7 },
    { e: "👑", t: "30 din streak", got: sk.best >= 30 },
    { e: "📿", t: "1,000 tasbeeh", got: tsb >= 1000 },
    { e: "💎", t: "10,000 tasbeeh", got: tsb >= 10000 },
    { e: "📖", t: "100 page Quran", got: qp >= 100 },
    { e: "🕋", t: "Khatam-e-Quran", got: kh >= 30 },
    { e: "🌙", t: "30 roze", got: roza >= 30 }
  ];
}

/* ---------- TASBEEH ---------- */
const tsbState = () => Object.assign({ cur: "t1", counts: {}, rounds: {}, custom: [], total: 0 }, S.get("tsb", {}));
const allDhikr = ts => [...TASBEEH_PRESETS, ...(ts.custom || [])];
PAGES.tasbeeh = () => {
  const ts = tsbState(), dh = allDhikr(ts).find(x => x.id === ts.cur) || TASBEEH_PRESETS[0];
  const c = ts.counts[dh.id] || 0, r = ts.rounds[dh.id] || 0;
  let counter;
  if (set.tsbDesign === "beads") {
    const n = Math.min(dh.target, 33), filled = c % n === 0 && c > 0 ? n : c % n;
    let beads = ""; for (let i = 0; i < n; i++) { const a = (i / n) * Math.PI * 2 - Math.PI / 2; beads += `<span class="bd ${i < filled ? "on" : ""} ${i === filled - 1 ? "cur" : ""}" style="left:${50 + 45 * Math.cos(a)}%;top:${50 + 45 * Math.sin(a)}%"></span>`; }
    counter = `<div class="beads" id="tsbVis">${beads}<div class="ctr"><div><div class="num" id="tsbNum">${c}</div><div style="opacity:.8">/ ${dh.target}</div></div></div></div>`;
  } else if (set.tsbDesign === "digital") {
    counter = `<div class="digital"><div class="lcd"><div class="s">${esc(dh.name)} · ROUND ${r}</div><div class="num" id="tsbNum">${String(c).padStart(4, "0")}</div><div class="s">TARGET ${dh.target}</div></div><div class="press" id="tsbVis"></div></div>`;
  } else {
    const rr = 120, cc = 2 * Math.PI * rr;
    counter = `<div class="orb" id="tsbVis"><svg class="r" viewBox="0 0 272 272"><circle cx="136" cy="136" r="${rr}" stroke="rgba(255,255,255,.18)"/><circle id="tsbRing" cx="136" cy="136" r="${rr}" stroke="#fff" stroke-dasharray="${cc}" stroke-dashoffset="${cc * (1 - Math.min(c, dh.target) / dh.target)}" style="transition:stroke-dashoffset .2s"/></svg><div class="num" id="tsbNum">${c}</div><div class="of">/ ${dh.target}</div></div>`;
  }
  return header("Tasbeeh", `Aaj: ${(getDay(dkey(today())).tsb || 0).toLocaleString()} · Kul: ${(ts.total || 0).toLocaleString()}`, { right: `<button class="icon-btn" data-a="tsbStyle" aria-label="Design">${IC.palette}</button>` }) +
    `<div class="tsb-wrap bg-${set.tsbBg}">
      <div class="tsb-top"><button class="tsb-pill" data-a="tsbPick">${IC.list.replace("<svg", '<svg style="width:15px;height:15px;vertical-align:-3px"')} Zikr badlein</button><span class="tsb-pill" id="tsbRound">Round ${r}</span></div>
      <div class="tsb-dhikr"><div class="ar">${dh.ar ? esc(dh.ar) : ""}</div><div class="nm">${esc(dh.name)}</div></div>
      <div class="tsb-tap" id="tsbTap" role="button" aria-label="Count karein">${counter}</div>
      <div class="tsb-ctrl"><button data-a="tsbUndo">${IC.undo} −1</button><button data-a="tsbReset">${IC.reset} Reset</button></div>
    </div><div class="muted small" style="text-align:center;margin-top:10px">Kahin bhi tap karein · target poora hone par vibration</div>`;
};
AFTER.tasbeeh = () => {
  const tap = $("#tsbTap"); if (!tap) return;
  let last = 0;
  const hit = e => { e.preventDefault(); const nowT = Date.now(); if (nowT - last < 35) return; last = nowT; tsbInc(1); };
  tap.addEventListener("pointerdown", hit);
};
function tsbInc(n) {
  const ts = tsbState(), dh = allDhikr(ts).find(x => x.id === ts.cur) || TASBEEH_PRESETS[0];
  let c = (ts.counts[dh.id] || 0) + n; if (c < 0) c = 0;
  ts.counts[dh.id] = c;
  if (n > 0) {
    ts.total = (ts.total || 0) + 1;
    const k = dkey(today()), d = getDay(k); d.tsb = (d.tsb || 0) + 1; setDay(k, d);
  }
  let roundDone = false;
  if (n > 0 && c >= dh.target) { ts.rounds[dh.id] = (ts.rounds[dh.id] || 0) + 1; ts.counts[dh.id] = 0; roundDone = true; }
  S.set("tsb", ts);
  if (roundDone) { vib(320); toast(`✨ ${dh.target} mukammal! Round ${ts.rounds[dh.id]}`); render(); return; }
  vib(14);
  const num = $("#tsbNum"); if (!num) return;
  num.textContent = set.tsbDesign === "digital" ? String(c).padStart(4, "0") : c;
  const vis = $("#tsbVis"); if (vis) { vis.classList.add("pulse"); setTimeout(() => vis.classList.remove("pulse"), 90); }
  const ringEl = $("#tsbRing"); if (ringEl) { const cc = 2 * Math.PI * 120; ringEl.setAttribute("stroke-dashoffset", cc * (1 - c / dh.target)); }
  if (set.tsbDesign === "beads") { const bds = document.querySelectorAll(".beads .bd"), nn = bds.length, f = c % nn === 0 && c > 0 ? nn : c % nn; bds.forEach((b, i) => { b.classList.toggle("on", i < f); b.classList.toggle("cur", i === f - 1); }); }
  const sub = document.querySelector(".top .sub"); if (sub) sub.textContent = `Aaj: ${(getDay(dkey(today())).tsb || 0).toLocaleString()} · Kul: ${(ts.total || 0).toLocaleString()}`;
}

/* ---------- QURAN ---------- */
PAGES.quran = (pr) => {
  const mode = pr.mode || "surah";
  const lr = S.get("lastRead"), bm = S.get("bookmarks", []);
  const tabs = `<div class="seg" style="margin-bottom:12px"><button style="flex:1;padding:9px" class="${mode === "surah" ? "on" : ""}" data-a="qMode" data-m="surah">Surah</button><button style="flex:1;padding:9px" class="${mode === "para" ? "on" : ""}" data-a="qMode" data-m="para">Para</button><button style="flex:1;padding:9px" class="${mode === "bm" ? "on" : ""}" data-a="qMode" data-m="bm">Bookmarks</button></div>`;
  const cont = lr ? `<div class="card hero" data-a="openSurah" data-n="${lr.s}" data-ayah="${lr.a}" style="cursor:pointer;padding:16px"><div class="label">Jahan chhoda tha</div><div style="font-size:22px;font-weight:600;margin-top:2px">${SURAHS[lr.s - 1].name}</div><div class="count">Ayat ${lr.a} · Tap karke jaari rakhein →</div></div>` : "";
  let body = "";
  if (mode === "surah") body = `<div class="search">${IC.search.replace("<svg", '<svg style="width:18px;height:18px;color:var(--faint)"')}<input id="qSearch" placeholder="Surah dhoondein (naam ya number)" autocomplete="off"></div><div class="card" style="padding:4px 14px" id="surahList">${surahRows(SURAHS)}</div>`;
  else if (mode === "para") body = `<div class="card" style="padding:4px 14px">${PARAS.map(p => `<div class="surah" data-a="openSurah" data-n="${p.surah}" data-ayah="${p.ayah}" style="cursor:pointer"><div class="no">${p.no}</div><div class="nm"><b>${p.name}</b><span>${SURAHS[p.surah - 1].name} ${p.surah}:${p.ayah} se</span></div><span class="chev">${IC.next.replace("<svg", '<svg style="width:18px"')}</span></div>`).join("")}</div>`;
  else body = bm.length ? `<div class="card" style="padding:4px 14px">${bm.map(b => { const [s, a] = b.split(":").map(Number); return `<div class="surah" data-a="openSurah" data-n="${s}" data-ayah="${a}" style="cursor:pointer"><div class="no">${s}</div><div class="nm"><b>${SURAHS[s - 1].name}</b><span>Ayat ${a}</span></div><span class="chev">${IC.next.replace("<svg", '<svg style="width:18px"')}</span></div>`; }).join("")}</div>` : `<div class="empty"><span class="e">🔖</span>Abhi koi bookmark nahi. Kisi bhi ayat par 🔖 dabayein.</div>`;
  return header("Quran-e-Kareem", "114 Surah · 30 Para · Tarjuma aur tilawat") + cont + tabs + body;
};
const surahRows = list => list.map(s => `<div class="surah" data-a="openSurah" data-n="${s.no}" style="cursor:pointer"><div class="no">${s.no}</div><div class="nm"><b>${s.name}</b><span>${s.ayahs} ayaat</span></div><span class="chev">${IC.next.replace("<svg", '<svg style="width:18px"')}</span></div>`).join("") || `<div class="empty">Koi surah nahi mili</div>`;
AFTER.quran = () => {
  const inp = $("#qSearch"); if (!inp) return;
  inp.addEventListener("input", () => { const q = inp.value.trim().toLowerCase().replace(/[^a-z0-9]/g, ""); $("#surahList").innerHTML = surahRows(SURAHS.filter(s => !q || String(s.no) === q || s.name.toLowerCase().replace(/[^a-z0-9]/g, "").includes(q))); });
};

async function cachedJSON(url) {
  let cache = null;
  try { if (window.caches) cache = await caches.open("quran-v1"); } catch (e) {}
  if (cache) { const hit = await cache.match(url); if (hit) return hit.json(); }
  const res = await fetch(url); if (!res.ok) throw new Error("HTTP " + res.status);
  if (cache) { try { await cache.put(url, res.clone()); } catch (e) {} }
  return res.json();
}
const TRANS = { ur: ["ur.jalandhry", "ur.junagarhi", "ur.ahmedali"], en: ["en.sahih", "en.asad"] };
async function loadSurah(n) {
  const tr = set.translation;
  if (tr === "none") { const j = await cachedJSON(`${API}/surah/${n}/quran-uthmani`); return { ar: j.data.ayahs, tr: null }; }
  let lastErr;
  for (const ed of TRANS[tr] || TRANS.ur) {
    try { const j = await cachedJSON(`${API}/surah/${n}/editions/quran-uthmani,${ed}`); if (j.data && j.data[1]) return { ar: j.data[0].ayahs, tr: j.data[1].ayahs }; } catch (e) { lastErr = e; }
  }
  throw lastErr || new Error("load failed");
}
PAGES.surah = (pr) => {
  const s = SURAHS[pr.n - 1];
  return header(s.name, `Surah ${s.no} · ${s.ayahs} ayaat`, { right: `<button class="icon-btn" data-a="playSurah" aria-label="Tilawat">${IC.play}</button>` }) +
    `<div class="qhead"><div style="opacity:.8;font-size:13px">Surah ${s.no}</div><h2>${s.name}</h2><div style="opacity:.8;font-size:13px">${s.ayahs} ayaat</div></div><div id="ayahs"><div class="spinner"></div><div class="muted small" style="text-align:center">Quran load ho raha hai…</div></div>`;
};
AFTER.surah = async (pr) => {
  const box = $("#ayahs"); const n = pr.n;
  try {
    const data = await loadSurah(n);
    if (cur().page !== "surah" || cur().params.n !== n) return;
    const bm = S.get("bookmarks", []);
    const isUr = set.translation === "ur";
    let showBism = n !== 1 && n !== 9;
    const html = data.ar.map((a, i) => {
      let text = a.text;
      if (i === 0 && showBism) { const w = text.split(" "); if (w[0].replace(/[ً-ٰۖ-ۭ]/g, "").startsWith("بسم")) text = w.slice(4).join(" "); }
      const key = `${n}:${a.numberInSurah}`;
      return `<div class="ayah ${bm.includes(key) ? "mark" : ""}" id="a${a.numberInSurah}" data-n="${a.numberInSurah}"><div class="ar" style="--qsize:${set.qsize}px">${esc(text)} <span style="color:var(--primary);font-size:.8em">﴿${toArabicNum(a.numberInSurah)}﴾</span></div>${data.tr ? `<div class="tr ${isUr ? "urdu" : ""}">${esc(data.tr[i].text)}</div>` : ""}<div class="meta"><span class="an">${n}:${a.numberInSurah}</span><span style="flex:1"></span><button class="mini-btn" data-a="playFrom" data-i="${i}" aria-label="Suniye">${IC.play}</button><button class="mini-btn ${bm.includes(key) ? "on" : ""}" data-a="bookmark" data-k="${key}" aria-label="Bookmark">${bm.includes(key) ? IC.markF : IC.mark}</button><button class="mini-btn" data-a="share" data-text="${esc(text + (data.tr ? "\n\n" + data.tr[i].text : "") + `\n(${SURAHS[n - 1].name} ${key})`)}" aria-label="Share">${IC.share}</button></div></div>`;
    }).join("");
    box.innerHTML = (showBism ? `<div class="ar bism">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</div>` : "") + html + `<div class="muted small" style="text-align:center;padding:18px 0">Text: Tanzil (Uthmani) · Tarjuma: ${set.translation === "ur" ? "Fateh Muhammad Jalandhry" : set.translation === "en" ? "Saheeh International" : "—"} · via AlQuran.cloud</div>`;
    if (pr.ayah) { const el = $("#a" + pr.ayah); if (el) setTimeout(() => el.scrollIntoView({ block: "start" }), 50); }
    else S.set("lastRead", { s: n, a: 1 });
    // track last read
    if ("IntersectionObserver" in window) {
      let tm;
      const io = new IntersectionObserver(ents => { const v = ents.filter(e => e.isIntersecting).map(e => +e.target.dataset.n); if (v.length) { clearTimeout(tm); tm = setTimeout(() => S.set("lastRead", { s: n, a: Math.min(...v) }), 600); } }, { rootMargin: "-20% 0px -60% 0px" });
      document.querySelectorAll(".ayah").forEach(el => io.observe(el));
    }
  } catch (e) {
    box.innerHTML = `<div class="empty"><span class="e">📶</span>Quran load nahi hua. Internet check karein.<br><span class="small">Jo surah ek baar khul jaati hai woh baad mein bina internet bhi khulegi.</span><br><br><button class="btn solid" data-a="retrySurah">Dobara koshish</button></div>`;
  }
};
const toArabicNum = n => String(n).replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[d]);

/* Audio */
let audio = null, aq = { list: [], i: 0, surah: 0 };
async function playFrom(i) {
  const n = cur().params.n;
  try {
    toast("Tilawat load ho rahi hai…");
    const j = await cachedJSON(`${API}/surah/${n}/ar.alafasy`);
    aq = { list: j.data.ayahs.map(a => a.audio), i, surah: n };
    playIdx();
  } catch (e) { toast("Audio load nahi hua. Internet check karein."); }
}
function playIdx() {
  if (!audio) { audio = new Audio(); audio.addEventListener("ended", () => { aq.i++; if (aq.i < aq.list.length) playIdx(); else stopAudio(); }); }
  audio.src = aq.list[aq.i]; audio.play().catch(() => {});
  document.querySelectorAll(".ayah.playing").forEach(e => e.classList.remove("playing"));
  const el = $("#a" + (aq.i + 1)); if (el) { el.classList.add("playing"); el.scrollIntoView({ behavior: "smooth", block: "center" }); }
  showPlayer();
}
function showPlayer() {
  let p = $("#player"); if (!p) { p = document.createElement("div"); p.id = "player"; p.className = "player"; document.body.appendChild(p); }
  p.innerHTML = `<div style="flex:1;font-size:13.5px"><b>${SURAHS[aq.surah - 1].name}</b> · Ayat ${aq.i + 1}<div style="font-size:11.5px;opacity:.7">Mishary Rashid Alafasy</div></div><button data-a="audioToggle">${audio && !audio.paused ? IC.pause : IC.play}</button><button data-a="audioStop">${IC.stop}</button>`;
}
function stopAudio() { if (audio) { audio.pause(); } const p = $("#player"); if (p) p.remove(); document.querySelectorAll(".ayah.playing").forEach(e => e.classList.remove("playing")); }

/* ---------- MORE ---------- */
PAGES.more = () => {
  const T = (p, e, l, g, extra = "") => `<button class="tile" data-a="go" data-p="${p}" ${extra}><span class="ti ${g ? "g" : ""}">${e}</span>${l}</button>`;
  return header("Aur Features", "Sab kuch ek jagah") +
    `<div class="sec-title" style="margin-top:4px">Ramadan</div><div class="tiles">${T("ramadan", "🌙", "Ramadan Hub", 1)}${T("timetable", "🕰️", "Sehri / Iftar")}${T("khatam", "📖", "Khatam Planner", 1)}${T("qadr", "✨", "Shab-e-Qadr")}${T("zakat", "💰", "Zakat", 1)}${T("fitra", "🌾", "Fitra")}</div>
    <div class="sec-title">Ibadat</div><div class="tiles">${T("azkaar", "🌄", "Subah Azkaar", 0, 'data-type="morning"')}${T("azkaar", "🌆", "Shaam Azkaar", 1, 'data-type="evening"')}${T("duas", "🤲", "Masnoon Duayein")}${T("myduas", "📝", "Meri Duayein", 1)}${T("qibla", "🧭", "Qibla")}${T("calendar", "📅", "Islami Calendar", 1)}</div>
    <div class="sec-title">Progress aur Ghar</div><div class="tiles">${T("report", "📊", "Report")}${T("kids", "⭐", "Bachon ka Mode", 1)}${T("settings", "⚙️", "Settings")}</div>
    <div class="card" style="margin-top:18px"><h3>🤍 ${APP_NAME} ke baare mein</h3><div class="muted small">Version ${APP_VERSION}. Saara data aapke phone mein hi rehta hai. Koi account ya login nahi chahiye. Agar app pasand aaye to doston ko share karein, yeh sadqa-e-jaariya hai.</div><div class="actions"><button class="btn sm solid" data-a="shareApp">${IC.share} App share karein</button></div></div>`;
};

/* ---------- RAMADAN HUB ---------- */
PAGES.ramadan = () => {
  const td = today(), ram = isRamadan(td), rs = ramadanStart(td);
  let hero;
  if (ram) { const dn = ramadanDay(td); hero = `<div class="card hero">${moonSVG}<div class="label">Ramadan Kareem ${hijri(td).y}</div><div class="big">Roza ${dn}</div><div class="bar" style="background:rgba(255,255,255,.2);margin-top:10px"><i style="width:${dn / 30 * 100}%;background:#fff"></i></div><div class="count" style="margin-top:6px">${30 - dn > 0 ? `${30 - dn} roze baqi` : "Aakhri roza"} ${dn >= 21 ? "· Aakhri Ashra 🌟" : dn >= 11 ? "· Doosra Ashra" : "· Pehla Ashra"}</div></div>`; }
  else { const days = rs ? Math.round((rs - td) / 864e5) : 0; hero = `<div class="card hero">${moonSVG}<div class="label">Ramadan ${rs ? hijri(rs).y : ""} aane mein</div><div class="big">${days} din</div><div class="count">Andaazan ${rs ? `${WD[rs.getDay()]}, ${fmtDate(rs)} ${rs.getFullYear()}` : ""}</div><div class="small" style="opacity:.8;margin-top:6px">Chaand dekhne par 1 din aage-peeche ho sakta hai. Settings → Hijri adjust se theek karein.</div></div>`; }
  let rozaCount = 0; if (rs) for (let i = 0; i < 30; i++) { const d = getDay(dkey(addDays(rs, i))); if (d.roza === "r") rozaCount++; }
  const kh = S.get("khatam", { paras: [] }), khDone = (kh.paras || []).filter(Boolean).length;
  const iftarDua = DUAS.find(d => d.title === "Iftar ke waqt"), qadrDua = DUAS.find(d => d.title === "Shab-e-Qadr ki dua");
  return header("Ramadan Hub", "Roza, Quran, Qadr aur Zakat") + hero +
    `<div class="card"><div class="li" style="padding:4px 0;border:0" data-a="toggleForce"><div class="lt"><b>Ramadan Mode abhi chalayein</b><span>Test karne ke liye. Ramadan mein apne aap chalu ho jayega.</span></div><span class="switch ${set.ramadanForce ? "on" : ""}"></span></div></div>
    <div class="grid2" style="margin-bottom:14px"><div class="stat" data-a="go" data-p="timetable" style="cursor:pointer"><b>🕰️</b><span>Sehri / Iftar Timetable →</span></div><div class="stat" data-a="go" data-p="khatam" style="cursor:pointer"><b>${khDone}/30</b><span>Khatam-e-Quran para →</span></div><div class="stat"><b>${rozaCount}</b><span>Is Ramadan ke roze</span></div><div class="stat" data-a="go" data-p="qadr" style="cursor:pointer"><b>✨</b><span>Shab-e-Qadr checklist →</span></div></div>
    <div class="card daily"><h3>🍽️ ${iftarDua.title}</h3><div class="ar">${iftarDua.ar}</div><div class="tr">${iftarDua.ur}</div><div class="ref">${iftarDua.ref}</div></div>
    <div class="card daily"><h3>✨ ${qadrDua.title}</h3><div class="ar">${qadrDua.ar}</div><div class="tr">${qadrDua.ur}</div><div class="ref">${qadrDua.ref}</div></div>
    <div class="tiles"><button class="tile" data-a="go" data-p="zakat"><span class="ti g">💰</span>Zakat</button><button class="tile" data-a="go" data-p="fitra"><span class="ti">🌾</span>Fitra</button><button class="tile" data-a="tab" data-t="amaal"><span class="ti g">✅</span>Aaj ke Amaal</button></div>`;
};

/* ---------- TIMETABLE ---------- */
PAGES.timetable = () => {
  const td = today(), rs = ramadanStart(td) || td;
  let rows = "", txt = `🌙 Ramadan ${hijri(rs).y} — Sehri/Iftar (${set.city})\n`;
  for (let i = 0; i < 30; i++) {
    const d = addDays(rs, i), t = times(d), k = dkey(d);
    rows += `<tr class="${k === dkey(td) ? "today" : ""} ${(i + 1) >= 21 && (i + 1) % 2 === 1 ? "odd-night" : ""}"><td>${i + 1}</td><td>${WDS[d.getDay()]}, ${fmtDate(d)}</td><td>${fmtTime(t.fajr)}</td><td>${fmtTime(t.maghrib)}</td></tr>`;
    txt += `${i + 1}. ${fmtDate(d)} — Sehri ${fmtTime(t.fajr)} | Iftar ${fmtTime(t.maghrib)}\n`;
  }
  return header("Sehri / Iftar", `${esc(set.city)} · Ramadan ${hijri(rs).y}`) +
    `<div class="banner"><div class="em">⚠️</div><div><b>Ehtiyat zaroori hai</b><span>Sehri 5-10 minute pehle band karein. Apni masjid ke timetable se milane ke liye Settings → Minute adjust karein.</span></div></div>
    <div class="card" style="padding:8px 10px"><table class="tt"><thead><tr><th>Roza</th><th>Tareekh</th><th>Sehri khatam</th><th>Iftar</th></tr></thead><tbody>${rows}</tbody></table></div>
    <button class="btn block solid" data-a="share" data-text="${esc(txt)}">${IC.share} WhatsApp pe share karein</button>`;
};

/* ---------- KHATAM ---------- */
PAGES.khatam = () => {
  const kh = Object.assign({ paras: Array(30).fill(false), days: 30, start: dkey(today()) }, S.get("khatam", {}));
  const done = kh.paras.filter(Boolean).length;
  const elapsed = Math.max(0, Math.round((today() - fromKey(kh.start)) / 864e5));
  const left = Math.max(1, kh.days - elapsed), remain = 30 - done;
  const perDay = remain / left;
  return header("Khatam Planner", "Quran mukammal karne ka plan") +
    `<div class="card"><div class="row" style="gap:16px">${ring(Math.round(done / 30 * 100), 96, `${done}/30`)}<div style="flex:1"><div style="font-size:18px;font-weight:600">${done >= 30 ? "Khatam mubarak! 🎉" : `${remain} para baqi`}</div><div class="muted small">${done >= 30 ? "Allah qubool farmaye" : `${left} din mein · roz ~${perDay.toFixed(1)} para (~${Math.ceil(perDay * 20)} page)`}</div></div></div></div>
    <div class="card"><h3>🎯 Kitne din mein khatam?</h3><div class="seg">${[10, 15, 20, 30, 60].map(v => `<button style="flex:1" class="${kh.days === v ? "on" : ""}" data-a="khDays" data-v="${v}">${v} din</button>`).join("")}</div><div class="muted small" style="margin-top:8px">Shuruaat: ${fmtDate(fromKey(kh.start))} · <a href="#" data-a="khRestart" style="color:var(--primary)">Aaj se dobara shuru</a></div></div>
    <div class="card"><h3>📖 Para tick karein</h3><div class="para-grid">${kh.paras.map((v, i) => `<button class="${v ? "on" : ""}" data-a="khPara" data-i="${i}">${i + 1}</button>`).join("")}</div><div class="muted small" style="margin-top:10px">Para padhne ke liye Quran tab → Para kholein.</div></div>
    <button class="btn block ghost" data-a="tab" data-t="quran">📖 Quran kholein</button>`;
};

/* ---------- SHAB-E-QADR ---------- */
const QADR_ITEMS = [["isha", "Isha aur Taraweeh jamaat ke saath"], ["nafl", "Nafl namaz"], ["quran", "Quran tilawat"], ["dua", "Allahumma innaka afuwwun… dua"], ["istighfar", "Istighfar aur tauba"], ["sadqa", "Sadqa"]];
PAGES.qadr = () => {
  const y = (ramadanStart() ? hijri(ramadanStart()).y : hijri(today()).y);
  const data = S.get("qadr:" + y, {});
  const rs = ramadanStart();
  return header("Shab-e-Qadr", "Aakhri ashre ki taaq raatein") +
    `<div class="card daily"><div class="tr">${HADITH[14].text}</div><div class="ref">${HADITH[14].ref}</div></div>` +
    [21, 23, 25, 27, 29].map(n => {
      const nd = data[n] || {}, cnt = QADR_ITEMS.filter(([k]) => nd[k]).length;
      const dt = rs ? addDays(rs, n - 2) : null; // raat pichli shaam ko shuru hoti hai
      return `<div class="card"><h3>🌌 ${n}vi raat <span class="tag ${cnt === QADR_ITEMS.length ? "" : "gold"}">${cnt}/${QADR_ITEMS.length}</span></h3>${dt ? `<div class="muted small" style="margin:-6px 0 6px">${WD[dt.getDay()]} ${fmtDate(dt)} ki shaam (Maghrib) se</div>` : ""}<div class="list">${QADR_ITEMS.map(([k, l]) => `<div class="li" data-a="qadr" data-n="${n}" data-k="${k}" data-y="${y}" style="cursor:pointer;padding:10px 2px"><div class="lt"><b style="font-size:14px">${l}</b></div>${checkBox(nd[k])}</div>`).join("")}</div></div>`;
    }).join("");
};

/* ---------- AZKAAR ---------- */
PAGES.azkaar = (pr) => {
  const type = pr.type || "morning", list = AZKAAR[type], k = dkey(today()), d = getDay(k), az = (d.az || {});
  const doneN = list.filter(x => (az[x.id] || 0) >= x.count).length;
  return header(type === "morning" ? "Subah ke Azkaar" : "Shaam ke Azkaar", type === "morning" ? "Fajr ke baad se Zuhr tak" : "Asr ke baad se Maghrib/Isha tak") +
    `<div class="seg" style="margin-bottom:12px"><button style="flex:1;padding:9px" class="${type === "morning" ? "on" : ""}" data-a="azType" data-t="morning">🌄 Subah</button><button style="flex:1;padding:9px" class="${type === "evening" ? "on" : ""}" data-a="azType" data-t="evening">🌆 Shaam</button></div>
    <div class="card"><div class="row between"><b>${doneN} / ${list.length} mukammal</b><span class="tag">${Math.round(doneN / list.length * 100)}%</span></div><div class="bar" style="margin-top:10px"><i style="width:${doneN / list.length * 100}%"></i></div></div>` +
    list.map(x => { const c = az[x.id] || 0, full = c >= x.count; return `<div class="card daily" style="${full ? "border-color:var(--primary)" : ""}"><h3>${x.title} <span class="tag ${full ? "" : "gold"}">${x.count}x</span></h3><div class="ar">${x.ar}</div><div class="tr">${esc(x.ur)}</div><div class="ref">${x.ref}</div><div class="actions">${x.quran ? `<button class="btn sm ghost" data-a="openSurah" data-n="${x.quran}">📖 Kholein</button>` : ""}<button class="btn ${full ? "" : "solid"}" style="flex:1" data-a="azCount" data-id="${x.id}" data-type="${type}">${full ? "✓ Mukammal" : `Padha · ${c}/${x.count}`}</button></div></div>`; }).join("");
};

/* ---------- DUAS ---------- */
PAGES.duas = (pr) => {
  const cats = [...new Set(DUAS.map(d => d.cat))], cat = pr.cat || "all";
  const list = cat === "all" ? DUAS : DUAS.filter(d => d.cat === cat);
  return header("Masnoon Duayein", "Roz marrah ki sunnat duayein") +
    `<div style="display:flex;gap:8px;overflow-x:auto;padding-bottom:6px;margin-bottom:8px;scrollbar-width:none">${["all", ...cats].map(c => `<button class="tag ${c === cat ? "" : "gold"}" style="padding:8px 14px;font-size:13px;${c === cat ? "background:var(--primary);color:var(--on-primary)" : ""}" data-a="duaCat" data-c="${c}">${c === "all" ? "Sab" : c}</button>`).join("")}</div>` +
    list.map(d => `<div class="card daily"><h3>${d.title} <span class="tag gold">${d.cat}</span></h3><div class="ar">${d.ar}</div><div class="tr">${esc(d.ur)}</div><div class="ref">${d.ref}</div><div class="actions"><button class="btn sm" data-a="share" data-text="${esc(d.title + "\n\n" + d.ar + "\n\n" + d.ur + "\n(" + d.ref + ")")}">${IC.share} Share</button></div></div>`).join("");
};

/* ---------- MY DUAS ---------- */
PAGES.myduas = () => {
  const list = S.get("myduas", []);
  return header("Meri Duayein", "Apni duaon ki list, har namaz ke baad") +
    `<div class="card"><div class="field" style="margin:0"><textarea id="myDuaInp" class="inp" rows="2" placeholder="Apni dua likhein… jaise: Ammi ki sehat ke liye"></textarea></div><button class="btn solid block" style="margin-top:10px" data-a="addMyDua">${IC.plus} Dua jodein</button></div>` +
    (list.length ? list.map(d => `<div class="card" style="padding:14px"><div class="row"><div style="flex:1"><div style="${d.done ? "text-decoration:line-through;opacity:.6" : ""}">${esc(d.text)}</div>${d.done ? `<div class="small" style="color:var(--primary);margin-top:4px">Alhamdulillah, qubool hui 🤲</div>` : ""}</div><button class="mini-btn ${d.done ? "on" : ""}" data-a="myDuaDone" data-id="${d.id}" title="Qubool hui">✓</button><button class="mini-btn" data-a="myDuaDel" data-id="${d.id}">${IC.trash}</button></div></div>`).join("") : `<div class="empty"><span class="e">🤲</span>Abhi koi dua nahi. Upar se apni pehli dua likhein.</div>`);
};

/* ---------- QIBLA ---------- */
let compassOn = false;
PAGES.qibla = () => {
  const q = PrayerCalc.qibla(set.lat, set.lng);
  const dirs = `<b class="cd n">N</b><b class="cd e">E</b><b class="cd s">S</b><b class="cd w">W</b>`;
  return header("Qibla Direction", `${esc(set.city)} se`) +
    `<div class="card" style="text-align:center"><div class="compass"><div class="dial" id="dial">${dirs}<div class="needle" id="needle" style="transform:rotate(${q}deg)"></div><div style="position:absolute;inset:0;transform:rotate(${q}deg)"><span class="kaaba">🕋</span></div></div><div class="hub"></div></div>
    <div style="font-size:28px;font-weight:600">${Math.round(q)}°</div><div class="muted small">North (Shimaal) se ghadi ki disha mein</div><div id="qStatus" class="small" style="margin-top:10px;color:var(--primary)"></div>
    <button class="btn solid block" style="margin-top:14px" data-a="startCompass">🧭 Live compass chalayein</button>
    <div class="muted small" style="margin-top:10px">Phone ko seedha (flat) rakhein. Galat dikhe to phone ko 8 ki shakal mein ghumayein (calibrate). Location: Settings mein badlein.</div></div>`;
};
function startCompass() {
  const q = PrayerCalc.qibla(set.lat, set.lng);
  const handler = e => {
    let heading = null;
    if (e.webkitCompassHeading != null) heading = e.webkitCompassHeading;
    else if (e.absolute && e.alpha != null) heading = 360 - e.alpha;
    else if (e.alpha != null) heading = 360 - e.alpha;
    if (heading == null) return;
    const dial = $("#dial"); if (!dial) { window.removeEventListener("deviceorientationabsolute", handler); window.removeEventListener("deviceorientation", handler); compassOn = false; return; }
    dial.style.transform = `rotate(${-heading}deg)`;
    const diff = Math.abs(((q - heading + 540) % 360) - 180);
    const s = $("#qStatus"); if (s) s.textContent = diff < 5 ? "✅ Aap Qibla ki taraf hain" : `Phone ko ${Math.round(diff)}° aur ghumayein`;
  };
  const begin = () => { if (compassOn) return; compassOn = true; if ("ondeviceorientationabsolute" in window) window.addEventListener("deviceorientationabsolute", handler); else window.addEventListener("deviceorientation", handler); toast("Compass chalu ✓"); };
  if (window.DeviceOrientationEvent && typeof DeviceOrientationEvent.requestPermission === "function") DeviceOrientationEvent.requestPermission().then(r => r === "granted" ? begin() : toast("Permission nahi mili")).catch(() => toast("Compass support nahi"));
  else if (window.DeviceOrientationEvent) begin(); else toast("Is phone mein compass sensor nahi mila");
}

/* ---------- ZAKAT ---------- */
PAGES.zakat = () => {
  const z = Object.assign({ goldG: "", goldRate: "", silverG: "", silverRate: "", cash: "", biz: "", lent: "", debt: "", nisab: "silver" }, S.get("zakat", {}));
  const F = (id, label, ph) => `<div class="field"><label>${label}</label><input class="inp" inputmode="decimal" data-z="${id}" value="${esc(z[id])}" placeholder="${ph}"></div>`;
  return header("Zakat Calculator", "2.5% · saal guzarne par") +
    `<div class="card"><h3>⚖️ Nisab kis se?</h3><div class="seg"><button style="flex:1" class="${z.nisab === "silver" ? "on" : ""}" data-a="zNisab" data-v="silver">Chandi (612.36g)</button><button style="flex:1" class="${z.nisab === "gold" ? "on" : ""}" data-a="zNisab" data-v="gold">Sona (87.48g)</button></div><div class="muted small" style="margin-top:8px">Hanafi ulama aam taur par chandi ka nisab batate hain (ghareebon ke liye zyada faidemand).</div></div>
    <div class="card"><h3>🪙 Sona aur Chandi</h3><div class="grid2">${F("goldG", "Sona (gram)", "0")}${F("goldRate", "Aaj ka rate / gram (₹)", "0")}${F("silverG", "Chandi (gram)", "0")}${F("silverRate", "Aaj ka rate / gram (₹)", "0")}</div></div>
    <div class="card"><h3>💵 Paisa aur Maal</h3>${F("cash", "Cash + Bank balance (₹)", "0")}${F("biz", "Tijarat ka maal (₹)", "0")}${F("lent", "Diya hua qarz jo wapas milega (₹)", "0")}${F("debt", "Aap par qarz / dene wale bills (₹)", "0")}</div>
    <div id="zRes"></div><div class="muted small" style="padding:0 4px 10px">Yeh sirf andaza hai. Apni khaas soorat-e-haal ke liye kisi mufti se zaroor poochein.</div>`;
};
function zakatCalc() {
  const z = Object.assign({}, S.get("zakat", {}));
  document.querySelectorAll("[data-z]").forEach(i => z[i.dataset.z] = i.value);
  S.set("zakat", z);
  const n = k => parseFloat(String(z[k] || "").replace(/,/g, "")) || 0;
  const assets = n("goldG") * n("goldRate") + n("silverG") * n("silverRate") + n("cash") + n("biz") + n("lent") - n("debt");
  const nisabVal = (z.nisab || "silver") === "gold" ? 87.48 * n("goldRate") : 612.36 * n("silverRate");
  const r = $("#zRes"); if (!r) return;
  const inr = v => "₹" + Math.round(v).toLocaleString("en-IN");
  if (!nisabVal) { r.innerHTML = `<div class="card"><div class="muted">Nisab ke liye ${z.nisab === "gold" ? "sone" : "chandi"} ka aaj ka rate daalein.</div></div>`; return; }
  const due = assets >= nisabVal ? assets * 0.025 : 0;
  r.innerHTML = `<div class="card"><div class="grid2"><div class="stat"><b style="font-size:17px">${inr(assets)}</b><span>Kul zakati maal</span></div><div class="stat"><b style="font-size:17px">${inr(nisabVal)}</b><span>Nisab</span></div></div><div class="result" style="margin-top:12px">${due ? `<span class="muted small">Aap par zakat farz hai</span><b>${inr(due)}</b>` : `<span class="muted small">Maal nisab se kam hai</span><b style="font-size:20px">Zakat farz nahi</b>`}</div></div>`;
}
AFTER.zakat = () => { zakatCalc(); document.querySelectorAll("[data-z]").forEach(i => i.addEventListener("input", zakatCalc)); };

/* ---------- FITRA ---------- */
PAGES.fitra = () => {
  const f = Object.assign({ amt: "", people: 1 }, S.get("fitra", {}));
  const total = (parseFloat(f.amt) || 0) * f.people;
  return header("Sadqa-e-Fitr", "Eid ki namaz se pehle ada karein") +
    `<div class="card"><div class="field"><label>Fi kas (har shakhs) amount ₹</label><input class="inp" id="fAmt" inputmode="decimal" value="${esc(f.amt)}" placeholder="Apne shehar ki announcement dekhein"></div>
    <div class="li" style="border:0"><div class="lt"><b>Ghar ke afraad</b><span>Bachon samet, jinki taraf se dena hai</span></div><div class="stepper"><button data-a="fPeople" data-o="-1">−</button><span class="v">${f.people}</span><button data-a="fPeople" data-o="1">+</button></div></div>
    <div class="result"><span class="muted small">Kul Fitra</span><b id="fTot">₹${Math.round(total).toLocaleString("en-IN")}</b></div></div>
    <div class="muted small" style="padding:0 4px">Fitra ka amount har saal ulama/masjid announce karte hain (gehun, jau, khajoor ya kishmish ke hisaab se). Wahi amount yahan daalein.</div>`;
};
AFTER.fitra = () => { const i = $("#fAmt"); if (i) i.addEventListener("input", () => { const f = Object.assign({ people: 1 }, S.get("fitra", {})); f.amt = i.value; S.set("fitra", f); $("#fTot").textContent = "₹" + Math.round((parseFloat(f.amt) || 0) * f.people).toLocaleString("en-IN"); }); };

/* ---------- CALENDAR ---------- */
PAGES.calendar = () => {
  const td = today(), out = []; let beedh = null;
  for (let i = 0; i < 370 && out.length < 14; i++) {
    const d = addDays(td, i), h = hijri(d);
    const ev = ISLAMIC_DATES.find(e => e.m === h.m && e.d === h.d); if (ev) out.push({ d, h, ev, i });
    if (!beedh && h.d === 13 && h.m !== 9) beedh = { d, h, i };
  }
  const row = (d, h, title, note, i) => `<div class="li"><div class="ico" style="flex-direction:column;width:48px;height:48px;font-size:11px;line-height:1.1"><b style="font-size:17px">${d.getDate()}</b>${MO[d.getMonth()]}</div><div class="lt"><b>${title}</b><span>${hijriStr(h)} · ${note}</span></div><span class="tag ${i === 0 ? "" : "gold"}">${i === 0 ? "Aaj" : i + " din"}</span></div>`;
  const h0 = hijri(td);
  return header("Islami Calendar", `Aaj: ${hijriStr(h0)}`) +
    `<div class="card hero"><div class="label">Hijri tareekh</div><div class="big" style="font-size:32px">${h0.d} ${HIJRI_MONTHS[h0.m - 1]}</div><div class="count">${h0.y} Hijri · ${WD[td.getDay()]}, ${fmtDate(td)} ${td.getFullYear()}</div><div class="small" style="opacity:.8;margin-top:6px">Adjust: ${set.hijriAdj > 0 ? "+" : ""}${set.hijriAdj} din (Settings mein badlein)</div></div>
    ${beedh ? `<div class="card"><h3>🌕 Agle Ayyam-ul-Beedh</h3>${row(beedh.d, beedh.h, "13, 14, 15 " + HIJRI_MONTHS[beedh.h.m - 1], "Sunnat roze", beedh.i)}</div>` : ""}
    <div class="card"><h3>📅 Aane wale khaas din</h3><div class="list">${out.map(o => row(o.d, o.h, o.ev.title, o.ev.note, o.i)).join("")}</div></div>`;
};

/* ---------- KIDS ---------- */
PAGES.kids = () => {
  const kids = S.get("kids", []), k = dkey(today());
  return header("Bachon ka Mode", "Roz ke achhe kaam, stars ke saath ⭐") +
    (kids.length ? kids.map(c => { const d = S.get(`kid:${c.id}:${k}`, {}), n = KIDS_TASKS.filter(t => d[t.id]).length; return `<div class="card" data-a="go" data-p="kid" data-id="${c.id}" style="cursor:pointer"><div class="row"><div style="font-size:38px">${c.avatar || "🧒"}</div><div style="flex:1"><b style="font-size:17px">${esc(c.name)}</b><div class="muted small">Aaj ${n}/${KIDS_TASKS.length} stars · Kul ⭐ ${c.total || 0}</div><div class="bar" style="margin-top:8px"><i style="width:${n / KIDS_TASKS.length * 100}%;background:linear-gradient(90deg,#F2C94C,#F2994A)"></i></div></div></div></div>`; }).join("") : `<div class="empty"><span class="e">👧🧒</span>Apne bachon ko jodein. Woh roz apne achhe kaamon par star kamayenge.</div>`) +
    `<div class="card"><div class="field" style="margin-bottom:10px"><label>Bachche ka naam</label><input class="inp" id="kidName" placeholder="Jaise: Ayaan"></div><div class="row" style="gap:8px;margin-bottom:12px" id="avPick">${["🧒", "👧", "👦", "🧕", "👶"].map((a, i) => `<button class="mini-btn ${i === 0 ? "on" : ""}" style="width:44px;height:44px;font-size:22px" data-a="pickAv" data-v="${a}">${a}</button>`).join("")}</div><button class="btn solid block" data-a="addKid">${IC.plus} Bachcha jodein</button></div>`;
};
let pickedAv = "🧒";
PAGES.kid = (pr) => {
  const kids = S.get("kids", []), c = kids.find(x => x.id === pr.id); if (!c) return PAGES.kids();
  const k = dkey(today()), d = S.get(`kid:${c.id}:${k}`, {}), n = KIDS_TASKS.filter(t => d[t.id]).length;
  return header(`${c.avatar || "🧒"} ${esc(c.name)}`, `Aaj ${n} stars · Kul ⭐ ${c.total || 0}`) +
    `<div class="card hero" style="text-align:center"><div style="font-size:44px">${"⭐".repeat(Math.min(n, 5))}${n > 5 ? "🌟".repeat(n - 5) : ""}${n === 0 ? "✨" : ""}</div><div class="big" style="font-size:30px">${n === KIDS_TASKS.length ? "MashaAllah! Sab mukammal 🎉" : `${n} / ${KIDS_TASKS.length} stars`}</div></div>` +
    KIDS_TASKS.map(t => `<button class="kid-task ${d[t.id] ? "on" : ""}" style="width:100%;text-align:left" data-a="kidTask" data-id="${c.id}" data-t="${t.id}"><span class="e">${t.icon}</span>${t.label}<span class="star">⭐</span></button>`).join("") +
    `<button class="btn block danger" style="margin-top:14px" data-a="delKid" data-id="${c.id}">${IC.trash} Hatayein</button>`;
};

/* ---------- SETTINGS ---------- */
PAGES.settings = () => {
  const segT = [["light", "☀️ Day"], ["dark", "🌙 Night"], ["auto", "📱 Phone"]];
  const native = !!Plug("LocalNotifications");
  return header("Settings", APP_NAME + " v" + APP_VERSION) +
    `<div class="card"><h3>👤 Aapka naam</h3><input class="inp" id="setName" value="${esc(set.name)}" placeholder="Salaam mein dikhega (optional)"></div>
    <div class="card"><h3>🎨 Theme</h3><div class="seg">${segT.map(([v, l]) => `<button style="flex:1;padding:10px" class="${set.theme === v ? "on" : ""}" data-a="setTheme" data-v="${v}">${l}</button>`).join("")}</div><div class="muted small" style="margin-top:8px">"Phone" chunein to aapke phone ki dark/light setting follow hogi.</div></div>
    <div class="card"><h3>📍 Location</h3><select class="inp" id="setCity">${CITIES.map(c => `<option ${c.name === set.city ? "selected" : ""}>${c.name}</option>`).join("")}${CITIES.find(c => c.name === set.city) ? "" : `<option selected>${esc(set.city)}</option>`}</select><button class="btn block" style="margin-top:10px" data-a="gps">${IC.loc} Meri location (GPS) use karein</button></div>
    <div class="card"><h3>🕌 Namaz ke auqaat</h3><div class="field"><label>Calculation method</label><select class="inp" id="setMethod">${Object.entries(PrayerCalc.METHODS).map(([k, m]) => `<option value="${k}" ${set.method === k ? "selected" : ""}>${m.name}</option>`).join("")}</select></div>
      <label class="muted small">Asr</label><div class="seg" style="margin:6px 0 12px"><button style="flex:1" class="${set.asr === "hanafi" ? "on" : ""}" data-a="setAsr" data-v="hanafi">Hanafi</button><button style="flex:1" class="${set.asr === "shafi" ? "on" : ""}" data-a="setAsr" data-v="shafi">Shafi / Ahle Hadith</button></div>
      <button class="btn block ghost" data-a="offsets">⏱️ Apni masjid ke hisaab se minute adjust</button></div>
    <div class="card"><h3>🌙 Hijri tareekh</h3><div class="li" style="border:0"><div class="lt"><b>Adjust (din)</b><span>India mein aam taur par −1. Chaand ke elaan se milayein.</span></div><div class="stepper"><button data-a="hijriAdj" data-o="-1">−</button><span class="v">${set.hijriAdj > 0 ? "+" : ""}${set.hijriAdj}</span><button data-a="hijriAdj" data-o="1">+</button></div></div><div class="muted small">Aaj: ${hijriStr(hijri(today()))}</div>
      <div class="li" data-a="toggleForce" style="cursor:pointer"><div class="lt"><b>Ramadan Mode zabardasti chalu</b><span>Test ke liye</span></div><span class="switch ${set.ramadanForce ? "on" : ""}"></span></div></div>
    <div class="card"><h3>📖 Quran</h3><label class="muted small">Tarjuma</label><div class="seg" style="margin:6px 0 12px"><button style="flex:1" class="${set.translation === "ur" ? "on" : ""}" data-a="setTr" data-v="ur">Urdu</button><button style="flex:1" class="${set.translation === "en" ? "on" : ""}" data-a="setTr" data-v="en">English</button><button style="flex:1" class="${set.translation === "none" ? "on" : ""}" data-a="setTr" data-v="none">Sirf Arabic</button></div>
      <div class="li" style="border:0"><div class="lt"><b>Arabic font size</b></div><div class="stepper"><button data-a="qsize" data-o="-2">−</button><span class="v">${set.qsize}</span><button data-a="qsize" data-o="2">+</button></div></div><div class="ar" style="font-size:${set.qsize}px;text-align:center">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</div></div>
    <div class="card"><h3>🔔 Reminders</h3>${native ? `
      <div class="li" data-a="remind" data-k="on" style="cursor:pointer"><div class="lt"><b>Reminders chalu</b><span>Notification ki permission maangi jayegi</span></div><span class="switch ${set.remind.on ? "on" : ""}"></span></div>
      ${set.remind.on ? `<div class="li" data-a="remind" data-k="azkaar" style="cursor:pointer"><div class="lt"><b>Subah / Shaam azkaar</b><span>Fajr aur Asr ke baad</span></div><span class="switch ${set.remind.azkaar ? "on" : ""}"></span></div>
      <div class="li" data-a="remind" data-k="namaz" style="cursor:pointer"><div class="lt"><b>Har namaz ka waqt</b></div><span class="switch ${set.remind.namaz ? "on" : ""}"></span></div>
      <div class="li" data-a="remind" data-k="ramadan" style="cursor:pointer"><div class="lt"><b>Sehri / Iftar alarm</b><span>Sehri se 45 min aur Iftar se 10 min pehle</span></div><span class="switch ${set.remind.ramadan ? "on" : ""}"></span></div>
      <div class="li" data-a="remind" data-k="quran" style="cursor:pointer"><div class="lt"><b>Roz Quran reminder</b><span>Waqt: <input type="time" id="qTime" value="${set.remind.quranTime}" class="inp" style="width:auto;padding:4px 8px;display:inline-block" onclick="event.stopPropagation()"></span></div><span class="switch ${set.remind.quran ? "on" : ""}"></span></div>` : ""}` : `<div class="muted small">Pakke notification reminders (azkaar, namaz, sehri/iftar) Android app mein milenge. Browser version mein yeh nahi chalte.</div>`}</div>
    <div class="card"><h3>📳 Tasbeeh</h3><div class="li" data-a="toggleVib" style="cursor:pointer;border:0"><div class="lt"><b>Vibration</b></div><span class="switch ${set.vibrate ? "on" : ""}"></span></div></div>
    <div class="card"><h3>💾 Data</h3><div class="muted small" style="margin-bottom:10px">Saara data sirf aapke phone mein hai. Naya phone lene se pehle backup le lein.</div><div class="grid2"><button class="btn" data-a="backup">⬇️ Backup</button><button class="btn" data-a="restore">⬆️ Restore</button></div><input type="file" id="restoreFile" accept=".json,application/json" style="display:none"><button class="btn block danger" style="margin-top:10px" data-a="wipe">Saara data mitayein</button></div>
    <div class="card"><h3>ℹ️ Content ke baare mein</h3><div class="muted small">Quran text: Tanzil (Uthmani) · Urdu tarjuma: Fateh Muhammad Jalandhry · English: Saheeh International · Tilawat: Mishary Rashid Alafasy · Source: AlQuran.cloud. Hadith ke references sahih kutub se diye gaye hain. Koi galti nazar aaye to humein zaroor batayein.</div></div>`;
};
AFTER.settings = () => {
  const n = $("#setName"); if (n) n.addEventListener("change", () => { set.name = n.value.trim().slice(0, 30); saveSet(); toast("Naam save ho gaya ✓"); });
  const c = $("#setCity"); if (c) c.addEventListener("change", () => { const ct = CITIES.find(x => x.name === c.value); if (ct) { set.city = ct.name; set.lat = ct.lat; set.lng = ct.lng; saveSet(); scheduleReminders(); toast(ct.name + " set ho gaya ✓"); } });
  const m = $("#setMethod"); if (m) m.addEventListener("change", () => { set.method = m.value; saveSet(); scheduleReminders(); toast("Method badal gaya ✓"); });
  const qt = $("#qTime"); if (qt) qt.addEventListener("change", () => { set.remind.quranTime = qt.value; saveSet(); scheduleReminders(); toast("Waqt save ✓"); });
  const rf = $("#restoreFile"); if (rf) rf.addEventListener("change", () => { const f = rf.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { try { const data = JSON.parse(r.result); if (!data.__noor) throw 0; Object.entries(data.items).forEach(([k, v]) => S.set(k, v)); set = Object.assign({}, DEF, S.get("settings", {})); applyTheme(); toast("Restore ho gaya ✓"); render(); } catch (e) { toast("Yeh sahi backup file nahi hai"); } }; r.readAsText(f); });
};

/* ============================================================
   REMINDERS (Android native)
   ============================================================ */
async function scheduleReminders() {
  const LN = Plug("LocalNotifications"); if (!LN) return;
  try {
    const pend = await LN.getPending(); if (pend.notifications.length) await LN.cancel({ notifications: pend.notifications.map(n => ({ id: n.id })) });
    if (!set.remind.on) return;
    const list = [], now = new Date();
    for (let i = 0; i < 7; i++) {
      const d = addDays(today(), i), t = times(d), base = 1000 + i * 20;
      const add = (id, at, title, body) => { if (at > now) list.push({ id: base + id, title, body, schedule: { at, allowWhileIdle: true } }); };
      if (set.remind.azkaar) { add(1, new Date(t.fajr.getTime() + 25 * 6e4), "🌄 Subah ke Azkaar", "5 minute nikaalein, din bhar hifazat mein rahein"); add(2, new Date(t.asr.getTime() + 20 * 6e4), "🌆 Shaam ke Azkaar", "Shaam ke azkaar ka waqt hai"); }
      if (set.remind.namaz) PR5.forEach(([k, n], j) => add(3 + j, t[k], `🕌 ${n} ka waqt`, `${n} ki namaz ka waqt ho gaya`));
      if (set.remind.quran) { const [hh, mm] = (set.remind.quranTime || "21:00").split(":").map(Number); const at = new Date(d); at.setHours(hh, mm, 0, 0); add(9, at, "📖 Quran ka waqt", "Aaj kuch page tilawat karein"); }
      if (set.remind.ramadan && isRamadanDate(d)) { add(10, new Date(t.fajr.getTime() - 45 * 6e4), "🍽️ Sehri ka waqt", `Sehri ${fmtTime(t.fajr)} par khatam`); add(11, new Date(t.maghrib.getTime() - 10 * 6e4), "🌙 Iftar 10 minute mein", `Iftar ${fmtTime(t.maghrib)} · dua yaad rakhein`); }
    }
    if (list.length) await LN.schedule({ notifications: list });
  } catch (e) { console.warn("reminder", e); }
}

/* ============================================================
   ACTIONS
   ============================================================ */
const A = {
  back: () => back(),
  tab: el => setTab(el.dataset.t),
  go: el => go(el.dataset.p, Object.assign({}, el.dataset)),
  share: el => share(el.dataset.text),
  shareApp: () => share(`Assalamu Alaikum! Main ${APP_NAME} app use kar raha hoon: namaz tracker, Quran, tasbeeh, azkaar, Sehri/Iftar timing, sab ek jagah aur bilkul free. Aap bhi try karein 🤲`),
  shareReport: el => share(el.dataset.txt),
  quickNamaz: el => { const k = dkey(today()), d = getDay(k); d.p = d.p || {}; const cur = d.p[el.dataset.k]; setNamaz(k, el.dataset.k, cur === "j" || cur === "a" ? "" : "a"); render(); },
  namaz: el => { const d = getDay(el.dataset.d); const curV = (d.p || {})[el.dataset.k]; setNamaz(el.dataset.d, el.dataset.k, curV === el.dataset.v ? "" : el.dataset.v); render(); },
  toggleDay: el => { const d = getDay(el.dataset.d); d[el.dataset.k] = !d[el.dataset.k]; setDay(el.dataset.d, d); vib(); render(); },
  qp: el => { const d = getDay(el.dataset.d); d.qp = Math.max(0, (d.qp || 0) + +el.dataset.o); setDay(el.dataset.d, d); vib(); render(); },
  roza: el => { const k = el.dataset.d, d = getDay(k), old = d.roza, nv = old === el.dataset.v ? "" : el.dataset.v; d.roza = nv; setDay(k, d); const q = qaza(); if (old !== "q" && nv === "q") q.roza++; if (old === "q" && nv !== "q") q.roza = Math.max(0, q.roza - 1); S.set("qaza", q); vib(); render(); },
  tar: el => { const d = getDay(el.dataset.d); d.tar = +el.dataset.v; setDay(el.dataset.d, d); vib(); render(); },
  amaalDay: el => { const c = cur(); const base = c.params.date ? fromKey(c.params.date) : today(); const nd = addDays(base, +el.dataset.o); if (nd > today()) return; c.params.date = dkey(nd); render(); },
  qaza: el => { const q = qaza(); q[el.dataset.k] = Math.max(0, q[el.dataset.k] + +el.dataset.o); S.set("qaza", q); render(); },
  addCustom: () => openSheet(`<h3>Naya amal jodein</h3><input class="inp" id="custInp" placeholder="Jaise: Surah Mulk padhna" maxlength="40"><button class="btn solid block" style="margin-top:12px" data-a="saveCustom">Save</button>`),
  saveCustom: () => { const v = ($("#custInp").value || "").trim(); if (!v) return; const l = S.get("customAmaal", []); l.push({ id: "c" + Date.now(), label: v }); S.set("customAmaal", l); closeSheet(); render(); },
  delCustom: el => { S.set("customAmaal", S.get("customAmaal", []).filter(c => c.id !== el.dataset.id)); render(); },
  toggleCustom: el => { const d = getDay(el.dataset.d); d.c = d.c || {}; d.c[el.dataset.id] = !d.c[el.dataset.id]; setDay(el.dataset.d, d); vib(); render(); },
  repMonth: el => { cur().params = { y: +el.dataset.y, m: +el.dataset.m }; render(); },
  /* tasbeeh */
  tsbUndo: () => tsbInc(-1),
  tsbReset: () => { const ts = tsbState(); ts.counts[ts.cur] = 0; ts.rounds[ts.cur] = 0; S.set("tsb", ts); render(); toast("Reset ✓"); },
  tsbPick: () => { const ts = tsbState(); openSheet(`<h3>Zikr chunein</h3><div class="list">${allDhikr(ts).map(x => `<div class="li" data-a="tsbSel" data-id="${x.id}" style="cursor:pointer"><div class="lt"><b>${esc(x.name)}</b><span>Target ${x.target} · Round ${ts.rounds[x.id] || 0}</span></div>${x.ar ? `<span class="ar" style="font-size:18px;line-height:1.4">${esc(x.ar)}</span>` : ""}${x.id.startsWith("u") ? `<button class="mini-btn" data-a="tsbDel" data-id="${x.id}">${IC.trash}</button>` : ""}${ts.cur === x.id ? `<span class="tag">✓</span>` : ""}</div>`).join("")}</div><div class="sec-title">Apna zikr jodein</div><input class="inp" id="tsbName" placeholder="Zikr ka naam" maxlength="40"><div class="row" style="margin-top:8px"><input class="inp" id="tsbTarget" inputmode="numeric" placeholder="Target (jaise 100)" style="flex:1"><button class="btn solid" data-a="tsbAdd">Jodein</button></div>`); },
  tsbSel: el => { const ts = tsbState(); ts.cur = el.dataset.id; S.set("tsb", ts); closeSheet(); render(); },
  tsbAdd: () => { const nm = ($("#tsbName").value || "").trim(), tg = parseInt($("#tsbTarget").value) || 100; if (!nm) return toast("Naam likhein"); const ts = tsbState(); const id = "u" + Date.now(); ts.custom = ts.custom || []; ts.custom.push({ id, name: nm, ar: "", target: Math.min(Math.max(tg, 1), 100000) }); ts.cur = id; S.set("tsb", ts); closeSheet(); render(); },
  tsbDel: (el, e) => { e.stopPropagation(); const ts = tsbState(); ts.custom = (ts.custom || []).filter(x => x.id !== el.dataset.id); if (ts.cur === el.dataset.id) ts.cur = "t1"; S.set("tsb", ts); closeSheet(); render(); },
  tsbStyle: () => {
    const bgs = [["aurora", "linear-gradient(160deg,#064E3B,#0E9F6E)"], ["night", "radial-gradient(#1E3A8A,#050816)"], ["gold", "linear-gradient(160deg,#9A6B14,#F2D27A)"], ["pattern", "#0B3B33"], ["rose", "linear-gradient(160deg,#831843,#F9A8D4)"]];
    openSheet(`<h3>Tasbeeh ka design</h3><div class="row" style="gap:8px">${[["orb", "🔮", "Noor"], ["beads", "📿", "Daane"], ["digital", "🔢", "Digital"]].map(([v, e, l]) => `<button class="design-opt ${set.tsbDesign === v ? "on" : ""}" data-a="tsbDesign" data-v="${v}"><span class="di">${e}</span>${l}</button>`).join("")}</div><div class="sec-title">Background</div><div class="swatches">${bgs.map(([v, c]) => `<button class="sw ${set.tsbBg === v ? "on" : ""}" style="background:${c}" data-a="tsbBg" data-v="${v}" aria-label="${v}"></button>`).join("")}</div><div style="height:10px"></div>`);
  },
  tsbDesign: el => { set.tsbDesign = el.dataset.v; saveSet(); closeSheet(); render(); },
  tsbBg: el => { set.tsbBg = el.dataset.v; saveSet(); closeSheet(); render(); },
  /* quran */
  qMode: el => { cur().params.mode = el.dataset.m; render(); },
  openSurah: el => { const n = +el.dataset.n; if (!n) return setTab("quran"); go("surah", { n, ayah: el.dataset.ayah ? +el.dataset.ayah : 0 }); },
  retrySurah: () => render(),
  bookmark: el => { let bm = S.get("bookmarks", []); const k = el.dataset.k; if (bm.includes(k)) { bm = bm.filter(x => x !== k); toast("Bookmark hataya"); } else { bm.unshift(k); toast("Bookmark ho gaya 🔖"); } S.set("bookmarks", bm.slice(0, 200)); el.classList.toggle("on"); el.innerHTML = bm.includes(k) ? IC.markF : IC.mark; el.closest(".ayah").classList.toggle("mark", bm.includes(k)); },
  playSurah: () => playFrom(0),
  playFrom: el => playFrom(+el.dataset.i),
  audioToggle: () => { if (!audio) return; if (audio.paused) audio.play(); else audio.pause(); showPlayer(); },
  audioStop: () => stopAudio(),
  /* ramadan */
  toggleForce: () => { set.ramadanForce = !set.ramadanForce; saveSet(); scheduleReminders(); toast(set.ramadanForce ? "Ramadan Mode chalu 🌙" : "Ramadan Mode band"); render(); },
  khDays: el => { const kh = Object.assign({ paras: Array(30).fill(false), start: dkey(today()) }, S.get("khatam", {})); kh.days = +el.dataset.v; S.set("khatam", kh); render(); },
  khRestart: (el, e) => { e.preventDefault(); const kh = Object.assign({ days: 30 }, S.get("khatam", {})); kh.start = dkey(today()); kh.paras = Array(30).fill(false); S.set("khatam", kh); toast("Naya khatam shuru, Bismillah 🤲"); render(); },
  khPara: el => { const kh = Object.assign({ paras: Array(30).fill(false), days: 30, start: dkey(today()) }, S.get("khatam", {})); const i = +el.dataset.i; kh.paras[i] = !kh.paras[i]; S.set("khatam", kh); vib(); if (kh.paras.filter(Boolean).length === 30) { confetti(); toast("Khatam-e-Quran mubarak! 🎉"); } render(); },
  qadr: el => { const key = "qadr:" + el.dataset.y, d = S.get(key, {}); d[el.dataset.n] = d[el.dataset.n] || {}; d[el.dataset.n][el.dataset.k] = !d[el.dataset.n][el.dataset.k]; S.set(key, d); vib(); render(); },
  /* azkaar */
  azType: el => { cur().params = { type: el.dataset.t }; render(); },
  azCount: el => {
    const type = el.dataset.type, k = dkey(today()), d = getDay(k); d.az = d.az || {};
    const item = AZKAAR[type].find(x => x.id === el.dataset.id); const c = d.az[item.id] || 0;
    if (c >= item.count) return;
    d.az[item.id] = c + 1; vib(c + 1 >= item.count ? 80 : 12);
    const allDone = AZKAAR[type].every(x => (d.az[x.id] || 0) >= x.count);
    const flag = type === "morning" ? "azM" : "azE";
    if (allDone && !d[flag]) { d[flag] = true; setDay(k, d); confetti(); toast("MashaAllah! Azkaar mukammal 🌟"); render(); return; }
    setDay(k, d);
    if (c + 1 >= item.count) render(); else el.textContent = `Padha · ${c + 1}/${item.count}`;
  },
  duaCat: el => { cur().params = { cat: el.dataset.c }; render(); },
  addMyDua: () => { const v = ($("#myDuaInp").value || "").trim(); if (!v) return toast("Pehle dua likhein"); const l = S.get("myduas", []); l.unshift({ id: "d" + Date.now(), text: v.slice(0, 500), done: false }); S.set("myduas", l); render(); },
  myDuaDone: el => { const l = S.get("myduas", []); const x = l.find(d => d.id === el.dataset.id); if (x) { x.done = !x.done; if (x.done) { confetti(); toast("Alhamdulillah 🤲"); } } S.set("myduas", l); render(); },
  myDuaDel: el => { S.set("myduas", S.get("myduas", []).filter(d => d.id !== el.dataset.id)); render(); },
  startCompass: () => startCompass(),
  zNisab: el => { const z = S.get("zakat", {}); z.nisab = el.dataset.v; S.set("zakat", z); render(); },
  fPeople: el => { const f = Object.assign({ amt: "", people: 1 }, S.get("fitra", {})); f.people = Math.max(1, f.people + +el.dataset.o); S.set("fitra", f); render(); },
  /* kids */
  pickAv: el => { pickedAv = el.dataset.v; document.querySelectorAll("#avPick .mini-btn").forEach(b => b.classList.toggle("on", b === el)); },
  addKid: () => { const n = ($("#kidName").value || "").trim(); if (!n) return toast("Naam likhein"); const l = S.get("kids", []); l.push({ id: "k" + Date.now(), name: n.slice(0, 20), avatar: pickedAv, total: 0 }); S.set("kids", l); render(); },
  kidTask: el => { const l = S.get("kids", []), c = l.find(x => x.id === el.dataset.id); const key = `kid:${c.id}:${dkey(today())}`, d = S.get(key, {}); d[el.dataset.t] = !d[el.dataset.t]; c.total = Math.max(0, (c.total || 0) + (d[el.dataset.t] ? 1 : -1)); S.set(key, d); S.set("kids", l); vib(d[el.dataset.t] ? 40 : 10); if (KIDS_TASKS.every(t => d[t.id])) { confetti(); toast("Shabash! 🎉 Sab stars mil gaye"); } render(); },
  delKid: el => openSheet(`<h3>Kya aap sach mein hatana chahte hain?</h3><div class="muted" style="margin-bottom:14px">Is bachche ke saare stars mit jayenge.</div><div class="grid2"><button class="btn ghost" data-a="closeSheet">Nahi</button><button class="btn danger" data-a="delKidYes" data-id="${el.dataset.id}">Haan, hatayein</button></div>`),
  delKidYes: el => { S.set("kids", S.get("kids", []).filter(x => x.id !== el.dataset.id)); S.keys(`kid:${el.dataset.id}:`).forEach(k => S.del(k)); closeSheet(); back(); },
  closeSheet: () => closeSheet(),
  /* settings */
  setTheme: el => { set.theme = el.dataset.v; saveSet(); applyTheme(); render(); },
  setAsr: el => { set.asr = el.dataset.v; saveSet(); scheduleReminders(); render(); },
  setTr: el => { set.translation = el.dataset.v; saveSet(); render(); },
  qsize: el => { set.qsize = Math.min(40, Math.max(18, set.qsize + +el.dataset.o)); saveSet(); render(); },
  hijriAdj: el => { set.hijriAdj = Math.min(2, Math.max(-2, set.hijriAdj + +el.dataset.o)); for (const k in hCache) delete hCache[k]; saveSet(); scheduleReminders(); render(); },
  toggleVib: () => { set.vibrate = !set.vibrate; saveSet(); render(); },
  offsets: () => openSheet(`<h3>Minute adjust (+ / −)</h3><div class="muted small" style="margin-bottom:8px">Apni masjid ke timetable se milane ke liye.</div><div class="list" id="offList">${offRows()}</div><button class="btn solid block" style="margin-top:12px" data-a="closeSheet">Ho gaya</button>`),
  off: el => { set.offsets[el.dataset.k] = Math.max(-30, Math.min(30, (set.offsets[el.dataset.k] || 0) + +el.dataset.o)); saveSet(); $("#offList").innerHTML = offRows(); scheduleReminders(); render(); },
  gps: () => {
    const done = (lat, lng) => { set.lat = +lat.toFixed(4); set.lng = +lng.toFixed(4); set.city = "Meri location"; saveSet(); scheduleReminders(); toast("Location set ho gayi ✓"); render(); };
    const G = Plug("Geolocation");
    if (G) { G.getCurrentPosition({ enableHighAccuracy: false, timeout: 15000 }).then(p => done(p.coords.latitude, p.coords.longitude)).catch(() => toast("Location nahi mili. Permission check karein.")); return; }
    if (!navigator.geolocation) return toast("Location support nahi");
    toast("Location dhoondh rahe hain…");
    navigator.geolocation.getCurrentPosition(p => done(p.coords.latitude, p.coords.longitude), () => toast("Location nahi mili. Permission check karein."), { timeout: 15000 });
  },
  remind: async el => {
    const k = el.dataset.k;
    if (k === "on" && !set.remind.on) { const LN = Plug("LocalNotifications"); try { const r = await LN.requestPermissions(); if (r.display !== "granted") return toast("Notification permission nahi mili"); } catch (e) { return toast("Notification support nahi"); } }
    set.remind[k] = !set.remind[k]; saveSet(); await scheduleReminders(); if (k === "on" && set.remind.on) toast("Reminders chalu ✓ agle 7 din ke"); render();
  },
  backup: async () => {
    const items = {}; S.keys("").forEach(k => items[k] = S.get(k));
    const txt = JSON.stringify({ __noor: 1, v: APP_VERSION, at: new Date().toISOString(), items });
    const name = `noor-amaal-backup-${dkey(today())}.json`;
    const FS = Plug("Filesystem");
    if (FS) { try { await FS.writeFile({ path: name, data: txt, directory: "DOCUMENTS", encoding: "utf8" }); toast("Backup Documents folder mein save ✓"); return; } catch (e) {} }
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([txt], { type: "application/json" })); a.download = name; document.body.appendChild(a); a.click(); a.remove(); toast("Backup download ✓");
  },
  restore: () => $("#restoreFile").click(),
  wipe: () => openSheet(`<h3>Saara data mitayein?</h3><div class="muted" style="margin-bottom:14px">Amaal, tasbeeh, bookmarks, duayein sab hamesha ke liye mit jayenge. Pehle backup le lein.</div><div class="grid2"><button class="btn ghost" data-a="closeSheet">Nahi</button><button class="btn danger" data-a="wipeYes">Haan, mitayein</button></div>`),
  wipeYes: () => { S.keys("").forEach(k => S.del(k)); set = Object.assign({}, DEF); applyTheme(); closeSheet(); setTab("home"); toast("Data mita diya gaya"); }
};
function offRows() { return PR.map(([k, n]) => `<div class="li"><div class="lt"><b>${n}</b><span>${fmtTime(times(today())[k])}</span></div><div class="stepper"><button data-a="off" data-k="${k}" data-o="-1">−</button><span class="v">${set.offsets[k] > 0 ? "+" : ""}${set.offsets[k] || 0}</span><button data-a="off" data-k="${k}" data-o="1">+</button></div></div>`).join(""); }
function setNamaz(k, key, v) {
  const d = getDay(k); d.p = d.p || {}; const old = d.p[key];
  d.p[key] = v; setDay(k, d);
  const q = qaza(); if (old !== "q" && v === "q") q.namaz++; if (old === "q" && v !== "q") q.namaz = Math.max(0, q.namaz - 1); S.set("qaza", q);
  vib(v ? 25 : 10);
  if (v && PR5.every(([x]) => d.p[x] === "j" || d.p[x] === "a")) { confetti(); toast("MashaAllah! Aaj ki 5 namazein mukammal 🌟"); }
}

document.addEventListener("click", e => {
  const el = e.target.closest("[data-a]"); if (!el) return;
  const fn = A[el.dataset.a]; if (fn) fn(el, e);
});
$("#sheetBg").addEventListener("click", closeSheet);
document.querySelectorAll(".nav button").forEach(b => b.addEventListener("click", () => { vib(8); setTab(b.dataset.tab); }));

/* live countdown */
let lastMin = new Date().getMinutes();
setInterval(() => {
  const now = Date.now();
  document.querySelectorAll("[data-cd]").forEach(el => { const t = +el.dataset.cd; if (t - now <= 0 && cur().page === "home") render(); else el.textContent = cdText(t - now); });
  const m = new Date().getMinutes(); if (m !== lastMin) { lastMin = m; if (cur().page === "home") render(); }
}, 1000);
document.addEventListener("visibilitychange", () => { if (!document.hidden && ["home", "amaal"].includes(cur().page)) render(); });

render(true);
scheduleReminders();
if ("serviceWorker" in navigator && !CAP && location.protocol === "https:") navigator.serviceWorker.register("sw.js").catch(() => {});
setTimeout(() => { const sp = $("#splash"); if (sp) { sp.style.opacity = 0; setTimeout(() => sp.remove(), 400); } }, 350);
})();
