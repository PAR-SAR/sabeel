/* Noor Amaal service worker — app offline chalane ke liye */
const VERSION = "noor-v1.0.0";
const CORE = [
  "./", "./index.html", "./manifest.json", "./css/app.css",
  "./js/capacitor.js", "./js/data.js", "./js/prayer.js", "./js/app.js",
  "./icons/icon-192.png", "./icons/icon-512.png",
  "./fonts/outfit-latin-300-normal.woff2", "./fonts/outfit-latin-400-normal.woff2", "./fonts/outfit-latin-500-normal.woff2",
  "./fonts/outfit-latin-600-normal.woff2", "./fonts/outfit-latin-700-normal.woff2",
  "./fonts/amiri-arabic-400-normal.woff2", "./fonts/amiri-arabic-700-normal.woff2", "./fonts/noto-nastaliq-urdu-arabic-400-normal.woff2"
];
self.addEventListener("install", e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION && k !== "quran-v1").map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET") return;
  if (url.origin === location.origin) {
    // app files: cache first, phir network se update
    e.respondWith(caches.match(e.request).then(hit => {
      const net = fetch(e.request).then(res => { if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(e.request, copy)); } return res; }).catch(() => hit);
      return hit || net;
    }));
  }
});
