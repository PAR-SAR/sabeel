# Noor Amaal: Android app project

Is folder mein poora Android app hai (Capacitor). APK banane ke liye Android Studio install karne ki zaroorat nahi hai. GitHub free mein bana deta hai.

## A. Pehla APK banana (testing ke liye), sirf ek baar ka setup

1. github.com par free account banayein (agar nahi hai).
2. **New repository** banayein, naam `noor-amaal`, **Private** rakhein.
3. Repository page par **"uploading an existing file"** dabayein aur is zip ki **saari files aur folders** (andar wali, `node_modules` ke baghair) drag-drop karein. Phir **Commit changes** dabayein.
   - Dhyan rakhein: `.github` folder bhi upload hona chahiye. Windows mein agar dikh nahi raha to File Explorer → View → "Hidden items" chalu karein.
4. Upar **Actions** tab kholein. "Android build" chal raha hoga (5-8 minute lagte hain).
5. Hara ✅ aane par us run ko kholein → neeche **Artifacts** → `NoorAmaal-debug-apk` download karein.
6. Zip kholkar `app-debug.apk` phone mein bhejein aur install karein (phone "Unknown apps" ki permission maangega, de dein).

Code mein badlaav karne ke baad files dobara upload karein. Har upload par naya APK apne aap banega.

## B. Play Store ke liye (December mein)

1. **Keystore banana** (app ki digital signature). Yeh file aur password hamesha ke liye sambhal kar rakhein. Kho gayi to app update nahi kar paayenge.
   Kisi bhi computer par jahan Java ho:
   ```
   keytool -genkey -v -keystore noor.jks -keyalg RSA -keysize 2048 -validity 10000 -alias noor
   ```
2. Keystore ko base64 mein badlein:
   - Windows PowerShell: `[Convert]::ToBase64String([IO.File]::ReadAllBytes("noor.jks")) | Set-Clipboard`
3. GitHub repo → **Settings → Secrets and variables → Actions → New repository secret**. Yeh 4 secrets daalein:
   - `NOOR_KEYSTORE_BASE64`: upar wala copy kiya text
   - `NOOR_KEYSTORE_PASSWORD`: keystore ka password
   - `NOOR_KEY_ALIAS`: `noor`
   - `NOOR_KEY_PASSWORD`: key ka password
4. Actions mein dobara run karein. Ab `NoorAmaal-playstore-aab` bhi milega. Yahi file Play Console mein upload hoti hai.
5. Play Console: naya app → **Closed testing** track → AAB upload → kam se kam 12 testers (behtar hai 15-20) ko invite karein → 14 din lagatar test → phir **Production** ke liye apply.

Har naye update par `android/app/build.gradle` mein `versionCode` 1 badhayein (1 → 2 → 3) aur `versionName` badlein.

## C. Naam ya content badalna

- App ka content (ayat, hadith, duayein): `www/js/data.js`
- App ka naam: `capacitor.config.json` (`appName`), `android/app/src/main/res/values/strings.xml`, aur `www/js/data.js` mein `APP_NAME`
- App ID `com.nooramaal.app` hai. Play Store pe ek baar upload ke baad yeh **kabhi nahi badal sakta**, isliye agar badalna hai to pehle upload se pehle badlein.

## Andar kya hai

- `www/`: app ka asli code (HTML/CSS/JS). Wahi code website pe bhi chalta hai.
- `android/`: Android wrapper. Isme notifications, vibration, share, GPS aur status bar ke native plugins hain.
- `.github/workflows/android.yml`: GitHub par APK/AAB banane ka nuskha.
